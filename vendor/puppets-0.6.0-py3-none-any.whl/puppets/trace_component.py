"""The clickable version of a unit graph: one self-contained HTML document.

``st.graphviz_chart`` draws a DOT string and nothing else — it reports no
clicks, so there is no way to ask Streamlit which node was pressed. This
module sidesteps that by rendering the *same* DOT in an iframe with
d3-graphviz, where a click is just a click and the answer never has to reach
Python at all: the full text of every step ships with the page, and selecting
a node swaps the detail panel client-side.

The trade is a dependency on three CDN scripts. When they do not load — no
network, a blocked CDN — the page says so instead of sitting blank, and the
caller offers the static chart, which carries the same text as hover tooltips.

Nothing here knows what an agent is. It takes a DOT string and a mapping of
node id to display fields, both from ``trace_graph``.
"""

from __future__ import annotations

import json

# Pinned majors, not "latest": a silent breaking change in a CDN script would
# take the graph out with no code change to point at.
_D3 = "https://cdn.jsdelivr.net/npm/d3@7"
_WASM = "https://cdn.jsdelivr.net/npm/@hpcc-js/wasm@2/dist/graphviz.umd.js"
_GRAPHVIZ = "https://cdn.jsdelivr.net/npm/d3-graphviz@5/build/d3-graphviz.js"
_FONT_CSS = ("https://fonts.googleapis.com/css2?"
             "family=IBM+Plex+Mono:wght@400;500;600&"
             "family=Outfit:wght@400;500;600&display=swap")

# Matches the app's palette. Duplicated rather than imported because this
# document renders inside an iframe that inherits none of the app's CSS.
_INK = "#011627"
_MUTED = "#6b7c85"
_LINE = "rgba(1,22,39,0.12)"
_PAPER = "#fdfffc"
_AGREE = "#1b998b"
_DISAGREE = "#e4572e"

_TEMPLATE = """<!doctype html>
<html>
<head>
<meta charset="utf-8">
<link rel="stylesheet" href="__FONT_CSS__">
<style>
  * { box-sizing: border-box; }
  body {
    margin: 0;
    font-family: 'Outfit', system-ui, sans-serif;
    color: __INK__;
    background: transparent;
  }
  #wrap { display: flex; gap: 0.9rem; height: __HEIGHT__px; }
  #graph {
    flex: 1 1 auto;
    min-width: 0;
    overflow: auto;
    border: 1px solid __LINE__;
    border-radius: 12px;
    background: __PAPER__;
  }
  #graph svg { max-width: none; }
  #graph .node { cursor: pointer; }
  #graph .node.dimmed { opacity: 0.35; }
  aside {
    flex: 0 0 300px;
    overflow-y: auto;
    padding: 0.9rem 1rem;
    border: 1px solid __LINE__;
    border-radius: 12px;
    background: __PAPER__;
  }
  .eyebrow {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.62rem;
    letter-spacing: 0.14em;
    text-transform: uppercase;
    color: __MUTED__;
  }
  h2 { font-size: 1.05rem; font-weight: 600; margin: 0.25rem 0 0.7rem 0; }
  dl { margin: 0 0 0.8rem 0; }
  dt {
    font-family: 'IBM Plex Mono', monospace;
    font-size: 0.66rem;
    letter-spacing: 0.08em;
    text-transform: uppercase;
    color: __MUTED__;
    margin-top: 0.55rem;
  }
  dd {
    margin: 0.15rem 0 0 0;
    font-size: 0.85rem;
    /* The whole point of this panel: the text is not clipped, not wrapped to
       a node's width, and long transcripts stay selectable. */
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }
  dd.mono { font-family: 'IBM Plex Mono', monospace; font-size: 0.78rem; }
  .agree { color: __AGREE__; font-weight: 600; }
  .disagree { color: __DISAGREE__; font-weight: 600; }
  .hint { color: __MUTED__; font-size: 0.85rem; line-height: 1.5; }
  #fallback { display: none; padding: 1rem; }
  #fallback.on { display: block; }
</style>
</head>
<body>
<div id="wrap">
  <div id="graph"><div id="fallback" class="hint">
    The interactive graph could not load its drawing library from the network.
    Untick <b>Click to inspect</b> to fall back to the static graph, which
    carries the same text on hover.
  </div></div>
  <aside>
    <span class="eyebrow">Step detail</span>
    <div id="panel"><p class="hint">Click any node to read what it decided,
    in full — the node labels are trimmed to fit, this is not.</p></div>
  </aside>
</div>
<script src="__D3__"></script>
<script src="__WASM__"></script>
<script src="__GRAPHVIZ__"></script>
<script>
  var DOT = __DOT__;
  var DETAIL = __DETAIL__;

  var FIELDS = [
    ["summary", "Final labels"], ["variable", "Variable"],
    ["value", "Answered"], ["gold", "Gold"],
    ["condition", "Ran when"], ["after", "After"], ["mode", "Flow"],
    ["status", "Status"],
    ["error", "Error"], ["reason", "In its own words"], ["model", "Model"],
    ["cost", "Cost"], ["duration", "Took"], ["tokens", "Tokens"]
  ];
  var MONO = {value: 1, gold: 1, model: 1, cost: 1, duration: 1, tokens: 1,
              condition: 1, after: 1, summary: 1, mode: 1};

  function escapeHtml(text) {
    return String(text).replace(/[&<>"]/g, function (c) {
      return {"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c];
    });
  }

  function show(id) {
    var step = DETAIL[id];
    if (!step) { return; }
    var html = '<h2>' + escapeHtml(step.label) + '</h2><dl>';
    for (var i = 0; i < FIELDS.length; i++) {
      var key = FIELDS[i][0];
      if (!step[key]) { continue; }
      var value = escapeHtml(step[key]);
      if (key === "value" && step.agrees) {
        value = '<span class="' + (step.agrees === "yes" ? "agree" : "disagree")
              + '">' + value + '</span>';
      }
      html += '<dt>' + FIELDS[i][1] + '</dt><dd'
            + (MONO[key] ? ' class="mono"' : '') + '>' + value + '</dd>';
    }
    document.getElementById("panel").innerHTML = html + '</dl>';

    // Dim the rest, so the panel and the graph agree on what is selected.
    d3.selectAll("#graph .node").classed("dimmed", function () {
      return d3.select(this).select("title").text() !== id;
    });
  }

  function wire() {
    d3.selectAll("#graph .node").on("click", function (event) {
      event.stopPropagation();
      show(d3.select(this).select("title").text());
    });
    // Clicking the paper clears the selection rather than trapping the reader
    // in whichever node they opened last.
    d3.select("#graph").on("click", function () {
      d3.selectAll("#graph .node").classed("dimmed", false);
    });
  }

  function draw() {
    var box = document.getElementById("graph");
    // Fit needs the box's real pixel size: told only to fit, d3-graphviz
    // keeps the SVG at its natural width and the left of the graph ends up
    // outside the frame. Re-measured on resize, since the panel and the
    // window both move it.
    d3.select("#graph").graphviz({useWorker: false, fit: true, zoom: true})
      .width(box.clientWidth)
      .height(box.clientHeight)
      .renderDot(DOT)
      .on("end", wire);
  }

  if (window.d3 && d3.select("#graph").graphviz) {
    draw();
    var redrawing = null;
    window.addEventListener("resize", function () {
      clearTimeout(redrawing);
      redrawing = setTimeout(draw, 200);
    });
  } else {
    document.getElementById("fallback").className = "on";
  }
</script>
</body>
</html>
"""


def _embed(value: object) -> str:
    """JSON for a <script> block, which is not the same as plain JSON.

    ``json.dumps`` escapes quotes but leaves ``<`` and ``>`` alone, so a
    reason containing ``</script>`` would end the block early and the rest of
    it would be parsed as markup. That is not hypothetical here: every reason
    in a trace is model output, and the labels come from a CSV anyone can
    edit. Escaping the three characters that can start a tag closes it off
    without changing what JSON.parse reads back. U+2028/9 are escaped too —
    legal in JSON, fatal inside a JavaScript literal.
    """
    return (
        json.dumps(value)
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("&", "\\u0026")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def unit_html(dot: str, detail: dict, *, height: int = 520) -> str:
    """A standalone page: the graph on the left, the clicked step on the right.

    ``detail`` maps node id to the display fields ``trace_graph.step_detail``
    produces. Both are embedded as JSON, so no escaping question survives into
    the JavaScript.
    """
    replacements = {
        "__DOT__": _embed(dot),
        "__DETAIL__": _embed(detail),
        "__HEIGHT__": str(height),
        "__D3__": _D3,
        "__WASM__": _WASM,
        "__GRAPHVIZ__": _GRAPHVIZ,
        "__FONT_CSS__": _FONT_CSS,
        "__INK__": _INK,
        "__MUTED__": _MUTED,
        "__LINE__": _LINE,
        "__PAPER__": _PAPER,
        "__AGREE__": _AGREE,
        "__DISAGREE__": _DISAGREE,
    }
    page = _TEMPLATE
    for token, value in replacements.items():
        page = page.replace(token, value)
    return page


__all__ = ["unit_html"]
