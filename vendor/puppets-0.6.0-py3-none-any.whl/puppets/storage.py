"""Run output: raw JSONL log of record, plus a flat CSV of labels.

The JSONL keeps the complete API response for every call, so a SQLite layer
(and the human-annotated benchmark comparison) can be rebuilt from it later
without re-running anything.
"""

from __future__ import annotations

import csv
import io
import json
import logging
from dataclasses import asdict
from pathlib import Path

from .config import REPO_ROOT
from .pipeline import LabelResult, RunSummary
from .schema import LABEL_FIELDS, REASON_FIELDS

logger = logging.getLogger(__name__)

# The label columns are derived from schema.LABEL_FIELDS, and the reason
# columns from schema.REASON_FIELDS — both in turn derived from
# schema.AD_FIELDS — so a new AD_SUBVARIABLES entry gets its column here
# automatically. Order is stable: LABEL_FIELDS is (*AD_FIELDS, "has_food",
# "is_upf"), so today's one ad column lands where `is_ad` used to.
CSV_COLUMNS = [
    "bundle_id",
    "n_images",
    "image_paths",
    *LABEL_FIELDS,
    # The dietary food group from category_agent. A string,
    # not a 0/1 label — empty when has_food is not 1, or when the food could
    # not be identified well enough to categorise.
    "food_category",
    # The paying brand(s) from brand_agent, JSON-encoded — ["Gymshark"] — so
    # that a multi-valued field survives a one-cell-per-column format without
    # a delimiter that could collide with a comma or a pipe inside a brand
    # name ("Ben & Jerry's", "Dolce, Gabbana"). Three distinct cells, matching
    # LabelResult.brands: empty when brand_agent was not asked (no ad
    # sub-flag was 1 — see pipeline.any_ad), "[]" when the unit is
    # advertising with no identifiable payer, and a JSON array otherwise.
    "brands",
    # The specific foods and drinks from foods_agent, JSON-encoded the same
    # way brands is, for the same reason and matching LabelResult.foods:
    # empty when foods_agent was not asked (has_food != 1), "[]" when food
    # is present but could not be named specifically enough, and a JSON
    # array otherwise.
    "foods",
    # Empty on a default run; filled when the run had rationale enabled.
    *REASON_FIELDS,
    "food_category_reason",
    "brands_reason",
    "foods_reason",
    # undisclosed_agent's answer before suppression blanked ad_undisclosed —
    # see pipeline.LabelResult.ad_undisclosed_raw. Deliberately here, at the
    # end of the answer columns rather than beside ad_undisclosed: it is not a
    # label, and the LABEL_FIELDS block above is a contiguous run of the
    # scored variables in registration order that analysis code and tests
    # address by position. A diagnostic column belongs after them, not inside
    # them. Filled on every row, so an empty cell means "no usable answer" and
    # never "this row was not suppressed".
    "ad_undisclosed_raw",
    "prompt_tokens",
    "completion_tokens",
    "cost_usd",
    "generation_id",
    "error",
    # Empty unless the run had audio escalation on and the audio channel
    # failed or had nothing to judge. Kept out of `error` on purpose — see
    # LabelResult.audio_error. The audio channel is currently disabled (see
    # Config.audio_escalation), so this column is empty on every run today.
    "audio_error",
]


def labels_csv(results: list[LabelResult]) -> str:
    """The flat analysis table as a string (also used for browser downloads)."""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=CSV_COLUMNS, lineterminator="\n")
    writer.writeheader()
    for result in results:
        row = result.as_row()
        row["n_images"] = result.n_images
        row["image_paths"] = "|".join(result.image_paths)
        # None stays an empty cell ("not asked"); a list — including the
        # empty one — is encoded, so "[]" reads as the distinct answer it is.
        if result.brands is not None:
            row["brands"] = json.dumps(result.brands, ensure_ascii=False)
        if result.foods is not None:
            row["foods"] = json.dumps(result.foods, ensure_ascii=False)
        writer.writerow({k: v for k, v in row.items() if k in CSV_COLUMNS})
    return buffer.getvalue()


def raw_jsonl(results: list[LabelResult]) -> str:
    """One JSON record per label set (one bundle of N images is one line), \
including the full API response."""
    return "".join(
        json.dumps(asdict(result), ensure_ascii=False) + "\n" for result in results
    )


def summary_json(summary: RunSummary) -> str:
    return json.dumps(asdict(summary), indent=2) + "\n"


def write_run(results: list[LabelResult], summary: RunSummary,
              runs_dir: Path | None = None) -> Path:
    out_dir = (runs_dir or REPO_ROOT / "runs") / summary.run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "raw.jsonl").write_text(raw_jsonl(results), encoding="utf-8")
    (out_dir / "labels.csv").write_text(labels_csv(results), encoding="utf-8")
    (out_dir / "summary.json").write_text(summary_json(summary), encoding="utf-8")
    logger.info("wrote run %s to %s (%d result(s))", summary.run_id, out_dir, len(results))
    return out_dir
