"""Reading screenshots off disk and encoding them for the API."""

from __future__ import annotations

import base64
import logging
import mimetypes
from pathlib import Path

logger = logging.getLogger(__name__)

SUPPORTED_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".gif"}


def collect_groups(paths: list[str]) -> list[list[Path]]:
    """Expand a mix of files and directories into video units, in argument order.

    One directory is one video: every image directly inside it is a frame of
    that video, sorted by name. One loose file is a one-frame video.

    This grouping is the whole reason bundle-based labelling can be trusted. A
    bundle is the unit of measurement — one verdict covers everything in it —
    so a bundle that straddles two videos asks the model to collapse two
    videos into one label set, and a video split across two bundles produces
    two verdicts where the data has one. Neither is recoverable after the
    fact, so the grouping has to come from the caller rather than from a
    slice width.
    """
    groups: list[list[Path]] = []
    for raw in paths:
        path = Path(raw).expanduser()
        if path.is_dir():
            frames = [
                p for p in sorted(path.iterdir())
                if p.suffix.lower() in SUPPORTED_SUFFIXES
            ]
            # An empty directory contributes no video rather than an empty bundle.
            if frames:
                groups.append(frames)
        elif path.is_file():
            if path.suffix.lower() not in SUPPORTED_SUFFIXES:
                logger.warning("unsupported image type: %s", path)
                raise SystemExit(f"Unsupported image type: {path}")
            groups.append([path])
        else:
            logger.warning("no such file or directory: %s", path)
            raise SystemExit(f"No such file or directory: {path}")
    if not groups:
        raise SystemExit("No images found in the given paths.")
    logger.info("collected %d video group(s) from %d path(s)", len(groups), len(paths))
    return groups


def to_data_url(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"
