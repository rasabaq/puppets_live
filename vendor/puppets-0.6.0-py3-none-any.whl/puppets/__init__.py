"""Sock-puppet audit pipeline — MVP labelling of screenshots via OpenRouter."""

__version__ = "0.1.0"
