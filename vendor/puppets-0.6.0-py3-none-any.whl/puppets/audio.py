"""Reading audio off disk, encoding it for the API, and caching transcripts.

The mirror of images.py for the audio evidence channel. Transcription goes to
the dedicated /audio/transcriptions endpoint (config.TRANSCRIPTIONS_URL), a
multipart upload, not /chat/completions. This module's job is the same as
images.to_data_url: get bytes off disk into the shape the API wants, and
fail clearly when it can't.
"""

from __future__ import annotations

import base64
import hashlib
import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

# OpenRouter's accepted `format` values. pcm16/pcm24 are raw sample formats
# with no natural file suffix, so they are reachable only by passing bytes
# directly, which this module does not do — every entry here is keyed from a
# real file on disk.
#
# Being in this map is necessary but not sufficient: a given model supports
# some subset of these, so an accepted format can still be rejected upstream.
# The guard here catches the common mistake (handing it a .mp4 or a .opus)
# before a multi-megabyte base64 payload goes out over three retries.
SUFFIX_TO_FORMAT = {
    ".wav": "wav",
    ".mp3": "mp3",
    ".aiff": "aiff",
    ".aif": "aiff",
    ".aac": "aac",
    ".ogg": "ogg",
    ".oga": "ogg",
    ".flac": "flac",
    ".m4a": "m4a",
}

# The "long audio" guard. This is a *size* limit, not a duration limit: with
# no ffprobe dependency there is no way to read a duration, and file size is
# the honest proxy — it is also the thing that actually breaks, since the
# payload is base64 (4/3 inflation) inside a JSON body that gets retried.
#
# Per the plan, long audio fails loudly rather than being chunked. The gold
# set is YouTube Shorts, where a whole video's audio is well under a
# megabyte, so this should never fire in normal use; if it does, it means
# someone attached a full-length video and needs to know that rather than
# watch a request time out three times.
MAX_AUDIO_BYTES = 20 * 1024 * 1024


class AudioError(RuntimeError):
    """Audio could not be prepared for the API.

    Deliberately not an OpenRouterError: nothing has been sent yet, and the
    fix is on this side (wrong file, wrong format, too big) rather than
    something to retry.
    """


def audio_format(path: Path) -> str:
    """The OpenRouter `format` string for this file, from its suffix."""
    suffix = path.suffix.lower()
    fmt = SUFFIX_TO_FORMAT.get(suffix)
    if fmt is None:
        supported = ", ".join(sorted(set(SUFFIX_TO_FORMAT)))
        logger.warning("unsupported audio type %r for %s", suffix, path.name)
        raise AudioError(
            f"Unsupported audio type {suffix or '(no suffix)'!r} for {path.name}. "
            f"Supported: {supported}. Convert the file first — this pipeline "
            f"does not transcode."
        )
    return fmt


def to_input_audio_part(path: Path) -> dict:
    """One `input_audio` content part: base64 payload plus its format."""
    fmt = audio_format(path)
    try:
        raw = path.read_bytes()
    except OSError as exc:
        raise AudioError(f"Could not read audio file {path}: {exc}") from exc
    if not raw:
        logger.warning("audio file is empty: %s", path)
        raise AudioError(f"Audio file is empty: {path}")
    if len(raw) > MAX_AUDIO_BYTES:
        logger.warning(
            "audio file %s is %.1f MB, over the %.0f MB limit",
            path.name, len(raw) / 1e6, MAX_AUDIO_BYTES / 1e6,
        )
        raise AudioError(
            f"Audio file {path.name} is {len(raw) / 1e6:.1f} MB, over the "
            f"{MAX_AUDIO_BYTES / 1e6:.0f} MB limit. Long audio is not chunked — "
            f"trim or downsample the file (mono 64 kbps mp3 is plenty for "
            f"speech) and try again."
        )
    return {
        "type": "input_audio",
        "input_audio": {
            "data": base64.b64encode(raw).decode("ascii"),
            "format": fmt,
        },
    }


def fingerprint(path: Path) -> str:
    """Content hash of the audio, used as the transcript cache key.

    Keyed on bytes rather than on the path or a video id on purpose: the same
    audio re-supplied under a different filename must hit the same cache
    entry, and an edited file under the *same* filename must miss it.
    """
    try:
        return hashlib.sha256(path.read_bytes()).hexdigest()
    except OSError as exc:
        raise AudioError(f"Could not read audio file {path}: {exc}") from exc


# --- Transcript cache ------------------------------------------------------
#
# Transcribing is the one step in this pipeline whose output depends on
# nothing but its input bytes and the model — not on a prompt under active
# development, not on the codebook. That makes it safe to cache, and worth
# caching: benchmarks re-run the same gold units on every prompt or model
# change, and without this each re-run pays to transcribe byte-identical
# audio again. With it, a unit is transcribed once, ever.
#
# The model id is part of the key. Two STT models will not produce the same
# transcript, so serving one model's transcript to a run configured for
# another would silently misreport what the run actually did.


@dataclass(frozen=True)
class Transcript:
    """A transcription result, whether freshly made or read from cache."""

    text: str
    language: str = ""
    has_speech: bool = True
    model: str = ""
    cost_usd: float = 0.0
    prompt_tokens: int = 0
    completion_tokens: int = 0
    # True when this came from the cache, so the caller can avoid
    # double-counting a cost that was already paid and recorded on the run
    # that first produced it.
    cached: bool = False

    def as_dict(self) -> dict:
        return {
            "text": self.text,
            "language": self.language,
            "has_speech": self.has_speech,
            "model": self.model,
            "cost_usd": self.cost_usd,
            "prompt_tokens": self.prompt_tokens,
            "completion_tokens": self.completion_tokens,
        }


def cache_path(cache_dir: Path, audio_fingerprint: str, model: str) -> Path:
    key = hashlib.sha256(f"{audio_fingerprint}\x00{model}".encode("utf-8")).hexdigest()
    return Path(cache_dir) / f"{key}.json"


def load_transcript(cache_dir: Path, audio_fingerprint: str,
                    model: str) -> Transcript | None:
    """Read a cached transcript, or None on a miss.

    A corrupt or unreadable cache file is a miss, not an error: the cache is
    an optimisation, and a run must never fail because of one. The cost of
    being wrong here is one extra API call.
    """
    path = cache_path(cache_dir, audio_fingerprint, model)
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        logger.debug("transcript cache miss for fingerprint=%s model=%s",
                     audio_fingerprint, model)
        return None
    if not isinstance(payload, dict) or "text" not in payload:
        logger.warning("transcript cache entry at %s is malformed", path)
        return None
    return Transcript(
        text=payload.get("text") or "",
        language=payload.get("language") or "",
        has_speech=bool(payload.get("has_speech", True)),
        model=payload.get("model") or "",
        # Cost and tokens are recorded for provenance but zeroed on the way
        # out: they were charged to the run that first transcribed this
        # audio. Adding them again on a cache hit would inflate every
        # subsequent benchmark's cost with money nobody spent.
        cost_usd=0.0,
        prompt_tokens=0,
        completion_tokens=0,
        cached=True,
    )


def store_transcript(cache_dir: Path, audio_fingerprint: str,
                     transcript: Transcript) -> Path:
    """Write a transcript to the cache. Best-effort: a failure to write is
    not a failure of the run, it just means the next run transcribes again."""
    path = cache_path(cache_dir, audio_fingerprint, transcript.model)
    payload = transcript.as_dict()
    payload["audio_sha256"] = audio_fingerprint
    payload["created_at"] = datetime.now(timezone.utc).isoformat()
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    except OSError:
        logger.exception("failed to write transcript cache entry at %s", path)
    return path
