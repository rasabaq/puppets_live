"""Gold-standard reference set: loading, joining, and agreement metrics.

Deliberately free of any API or filesystem-of-images concern, so the metrics
can be unit-tested without network access. The runner that actually calls the
model lives in ``scripts/evaluate_gold.py``.

This measures the *instrument*, not the code. tests/test_pipeline.py asserts
deterministic behaviour and must always pass; agreement here is statistical and
is expected to sit below 1.0 — the number is only meaningful compared against
the previous run and against human-human agreement on the same images.
"""

from __future__ import annotations

import csv
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path

from . import config
from .schema import (
    AD_FIELDS,
    FOOD_CATEGORY_VALUES,
    LABEL_FIELDS,
    MAX_BRANDS,
    MAX_FOODS,
    SUPPRESSING_AD_FIELDS,
    UNDISCLOSED_FIELD,
)

logger = logging.getLogger(__name__)

_gold_dir_override = os.environ.get("PUPPETS_GOLD_DIR", "").strip()
GOLD_DIR = (
    Path(_gold_dir_override) if _gold_dir_override
    else config.REPO_ROOT / "tests" / "fixtures" / "gold"
)
GOLD_CSV = GOLD_DIR / "gold.csv"
GOLD_IMAGES = GOLD_DIR / "images"
GOLD_AUDIO = GOLD_DIR / "audio"

# Demands the current registry's ad column(s) by name — see AD_FIELDS. A
# gold.csv still carrying the old flat `is_ad` column (predating the ad
# sub-variable registry) is missing "ad_paid_promotion" and load_gold raises
# a clear error rather than silently misreading it: the honest option is to
# tell the operator the CSV needs migrating, not to guess at a mapping. That
# migration (renaming the `is_ad` column to `ad_paid_promotion`) is a
# deferred, separate task.
REQUIRED_COLUMNS = ("image", *AD_FIELDS, "has_food", "is_upf", "rationale")

# The full column set written by save_gold, in file order. Only
# REQUIRED_COLUMNS are demanded on read: a hand-made gold.csv predating the
# provenance columns must still load, so everything below is optional input
# and merely round-trips.
# Every variable score_run() compares, in report order. food_category is
# scored alongside the three binaries but is not a member of LABEL_FIELDS —
# see GoldRow.food_category — so anything that wants "the scored variables"
# (the app's score table and charts included) reads this rather than
# rebuilding the tuple and drifting.
SCORED_FIELDS = (*LABEL_FIELDS, "food_category")

GOLD_COLUMNS = (
    "image", "video", "url", *AD_FIELDS, "has_food", "is_upf", "food_category",
    "brands", "foods", "rationale",
    "disputed", "title", "description", "channel", "published_at", "duration",
    "view_count", "uploader_comment", "audio",
)

# Written by the YouTube fetcher, never by hand in the builder UI.
METADATA_COLUMNS = ("title", "channel", "published_at", "duration", "view_count",
                    "uploader_comment")


@dataclass(frozen=True)
class GoldRow:
    """One hand-coded reference *unit* — a single screenshot, or a video given
    as several frames.

    The unit carries one set of labels, never one per frame, mirroring
    pipeline.LabelResult: a bundle of frames from one video produces a single
    verdict about that video. ``image`` holds the frames pipe-joined, the same
    encoding storage.labels_csv uses for bundle image paths.
    """

    image: str
    # One field per schema.AD_FIELDS member — hand-declared for the same
    # reason as pipeline.LabelResult: dataclass fields cannot be generated
    # from a tuple. Every CONSUMER loops over AD_FIELDS instead of naming a
    # field, so adding a sub-variable needs only a field here.
    ad_paid_promotion: int | None
    ad_paid_advertising: int | None
    ad_brand_owned: int | None
    ad_undisclosed: int | None
    has_food: int | None
    is_upf: int | None
    rationale: str
    disputed: bool
    # The dietary food group slug from schema.FOOD_CATEGORIES, or "" for
    # unlabelled. Scored like the binaries but kept out of LABEL_FIELDS and
    # REQUIRED_COLUMNS: it is an 8-way string, and every consumer of
    # LABEL_FIELDS assumes `int | None`.
    food_category: str = ""
    # The brands that paid for the promotion, comma-separated in one cell —
    # the same rendering cli._brands_str uses, and quoted by the csv module so
    # the commas never split the row. Recorded for analysis but NOT scored: the
    # vocabulary is open, so "Coca-Cola", "Coca Cola" and "Coke" are three
    # unequal strings and an agreement number over them would be noise.
    brands: str = ""
    # The foods and drinks visible on screen, comma-separated in one cell —
    # mirrors brands exactly, including why: recorded for analysis but NOT
    # scored. The vocabulary is open, so "fries", "french fries" and "chips"
    # are three unequal strings and an agreement number over them would be
    # noise.
    foods: str = ""
    # Provenance. ``url`` is the source YouTube video the frames were sampled
    # from; the rest is what the YouTube API reports about it. None of it is
    # used for scoring — it exists so a row can be traced back to, and
    # re-sampled from, the video it came from.
    video: str = ""
    url: str = ""
    title: str = ""
    channel: str = ""
    published_at: str = ""
    duration: str = ""
    view_count: str = ""
    # The uploader's own top-level comment, where they left one — often the
    # recipe or ingredient list. Provenance and context for a human coder;
    # it is never shown to the model, which judges only the frames.
    uploader_comment: str = ""
    # Optional: absent from older gold.csv exports and deliberately kept out
    # of REQUIRED_COLUMNS, so a CSV without them still loads. Feeds
    # agents.VideoMeta for the ad_agent benchmark path — see benchmarks.execute.
    description: str = ""
    # Filename in tests/fixtures/gold/audio/, or empty. A row without audio
    # simply never escalates, which is what keeps every gold row written
    # before this feature scoring exactly as it did.
    audio: str = ""

    @property
    def images(self) -> list[str]:
        """The frames making up this unit, in order."""
        return [name.strip() for name in self.image.split("|") if name.strip()]

    @property
    def brand_list(self) -> list[str]:
        """The brands for this unit, in order."""
        return [name.strip() for name in self.brands.split(",") if name.strip()]

    @property
    def food_list(self) -> list[str]:
        """The foods for this unit, in order."""
        return [name.strip() for name in self.foods.split(",") if name.strip()]

    @property
    def is_bundle(self) -> bool:
        return len(self.images) > 1

    @property
    def is_labelled(self) -> bool:
        """A row is usable once the required variables are filled in.

        is_upf is excluded from this check on purpose: a blank is_upf is a
        legitimate label (null) whenever has_food is 0, so requiring it would
        silently drop every no-food row from the evaluation.

        ad_undisclosed gets the same treatment whenever this row already has
        another ad flag set to 1 (schema.SUPPRESSING_AD_FIELDS): that mirrors
        pipeline._suppress_undisclosed, where the question becomes not
        applicable once another disclosure/ownership flag fires, and a human
        coder facing such a row is allowed to leave ad_undisclosed blank
        rather than coding a value the pipeline would never produce either.
        """
        required = [f for f in AD_FIELDS if f != UNDISCLOSED_FIELD]
        if not any(getattr(self, f) == 1 for f in SUPPRESSING_AD_FIELDS):
            required.append(UNDISCLOSED_FIELD)
        return (
            all(getattr(self, f) is not None for f in required)
            and self.has_food is not None
        )


def _parse_label(raw: str) -> int | None:
    """Blank means null/unlabelled; anything else must be 0 or 1."""
    value = raw.strip()
    if not value:
        return None
    if value not in ("0", "1"):
        raise ValueError(f"Label must be 0, 1, or blank — got {value!r}")
    return int(value)


# The sixteen Codex Alimentarius GSFA slugs food_category used before it moved
# to the eight dietary food groups, mapped onto their successor. Gold rows are
# hand-coded and expensive, so a CSV coded under the old scheme is migrated on
# load rather than rejected — dropping this map would silently invalidate
# every row already labelled.
#
# The four slugs that survived the change unaltered (beverages, dairy,
# fruits_and_vegetables, savoury_snacks) are absent: they need no translation.
#
# One collapse is lossy in a way worth naming. GSFA 07.0 bakery_wares held
# both bread and cakes, and lands wholly in grains_and_bakery — a row coded
# `bakery_wares` for a doughnut is now grains_and_bakery, which is where a
# coder applying the new scheme would also put it, since the sweet/plain
# split is is_upf's job and not this variable's.
_LEGACY_CATEGORIES = {
    "edible_ices": "sweets_and_desserts",
    "confectionery": "sweets_and_desserts",
    "sweeteners": "sweets_and_desserts",
    "cereals": "grains_and_bakery",
    "bakery_wares": "grains_and_bakery",
    "meat": "protein_foods",
    "fish": "protein_foods",
    "eggs": "protein_foods",
    "fats_and_oils": "prepared_and_other",
    "salts_spices_soups_sauces": "prepared_and_other",
    "special_nutritional_uses": "prepared_and_other",
    "composite_foods": "prepared_and_other",
}


def _parse_category(raw: str) -> str:
    """Blank means unlabelled; anything else must be a known category slug.

    Validated rather than passed through because a typo'd slug can never
    agree with the model, and would then read as a model miss in the
    disagreement list instead of as the data-entry error it is.

    A retired GSFA slug is translated to its successor instead of raising,
    so gold coded under the sixteen-category scheme still loads — see
    _LEGACY_CATEGORIES.
    """
    value = raw.strip()
    value = _LEGACY_CATEGORIES.get(value, value)
    if value and value not in FOOD_CATEGORY_VALUES:
        raise ValueError(f"Unknown food_category {value!r}")
    return value


def _parse_brands(raw: str) -> str:
    """Normalise the comma-separated brand cell, capped at schema.MAX_BRANDS.

    The cap is the one the model is held to, so a gold row may not carry more
    names than the model is ever allowed to answer with. A brand whose own
    name contains a comma cannot be represented here; none of the sponsors in
    the set do, and the alternative — a second escaping rule inside a CSV
    cell — costs more than it buys.
    """
    names = [name.strip() for name in raw.split(",") if name.strip()]
    if len(names) > MAX_BRANDS:
        raise ValueError(f"At most {MAX_BRANDS} brands — got {len(names)}")
    return ", ".join(names)


def _parse_foods(raw: str) -> str:
    """Normalise the comma-separated foods cell, capped at schema.MAX_FOODS.

    Mirrors _parse_brands exactly, including why: the cap is the one the
    model is held to, so a gold row may not carry more names than the model
    is ever allowed to answer with.
    """
    names = [name.strip() for name in raw.split(",") if name.strip()]
    if len(names) > MAX_FOODS:
        raise ValueError(f"At most {MAX_FOODS} foods — got {len(names)}")
    return ", ".join(names)


def load_gold(path: Path | None = None) -> list[GoldRow]:
    """Read gold.csv. Raises on a malformed file rather than coding around it."""
    path = path or GOLD_CSV
    with open(path, newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        missing = [c for c in REQUIRED_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise ValueError(f"{path} is missing columns: {', '.join(missing)}")
        rows = []
        for line_no, raw in enumerate(reader, start=2):
            try:
                rows.append(GoldRow(
                    image=raw["image"].strip(),
                    **{field: _parse_label(raw[field]) for field in AD_FIELDS},
                    has_food=_parse_label(raw["has_food"]),
                    is_upf=_parse_label(raw["is_upf"]),
                    rationale=raw["rationale"].strip(),
                    disputed=raw.get("disputed", "").strip().lower() in ("1", "true", "yes"),
                    **{
                        name: (raw.get(name) or "").strip()
                        for name in ("video", "url", "description", "audio",
                                     *METADATA_COLUMNS)
                    },
                    brands=_parse_brands(raw.get("brands", "")),
                    foods=_parse_foods(raw.get("foods", "")),
                    food_category=_parse_category(raw.get("food_category", "")),
                ))
            except ValueError as exc:
                raise ValueError(f"{path} line {line_no}: {exc}") from exc
    # An image may appear in only one unit: two units containing the same frame
    # would score that frame twice and silently weight it double.
    seen = [name for row in rows for name in row.images]
    duplicates = {name for name in seen if seen.count(name) > 1}
    if duplicates:
        raise ValueError(f"{path}: image in more than one unit: {', '.join(sorted(duplicates))}")
    logger.info("loaded %d gold row(s) from %s", len(rows), path)
    return rows


def _cell(value: int | None) -> str:
    """A null label is written as an empty cell — the encoding load_gold reads."""
    return "" if value is None else str(value)


def save_gold(rows: list[GoldRow], path: Path | None = None) -> Path:
    """Write the whole file back, atomically.

    Whole-file rewrite rather than append: the builder edits and deletes rows
    as well as adding them, and a half-written gold.csv would take the
    reference set with it, so the replace only happens once the temp file is
    complete.
    """
    path = path or GOLD_CSV
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    with open(temporary, "w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(GOLD_COLUMNS))
        writer.writeheader()
        for row in rows:
            writer.writerow({
                "image": row.image,
                "video": row.video,
                "url": row.url,
                **{field: _cell(getattr(row, field)) for field in AD_FIELDS},
                "has_food": _cell(row.has_food),
                "is_upf": _cell(row.is_upf),
                "food_category": row.food_category,
                "brands": row.brands,
                "foods": row.foods,
                "rationale": row.rationale,
                "disputed": "1" if row.disputed else "",
                "description": row.description,
                "audio": row.audio,
                **{name: getattr(row, name) for name in METADATA_COLUMNS},
            })
    temporary.replace(path)
    logger.info("saved %d gold row(s) to %s", len(rows), path)
    return path


def evaluable(rows: list[GoldRow]) -> list[GoldRow]:
    """Rows that count toward the headline numbers: labelled and not disputed."""
    return [r for r in rows if r.is_labelled and not r.disputed]


@dataclass
class Disagreement:
    image: str
    variable: str
    # `object` rather than `int | None`: food_category disagreements carry the
    # category slug on both sides.
    gold: object
    predicted: object
    rationale: str
    # The model's own justification for the label it picked, when the run had
    # rationale enabled. Deliberately a separate field from `rationale`, which
    # is the human coder's note from gold.csv: reading a disagreement means
    # comparing the two accounts, so collapsing them into one column would
    # destroy the only thing this field is for.
    model_rationale: str = ""


@dataclass(frozen=True)
class ScoringError:
    """A unit excluded from scoring because it has no usable prediction.

    Two distinct causes are conflated in n_errors and must not be conflated
    here: a unit missing from the run entirely (a pipeline bug) versus a unit
    whose prediction carries an ``error`` (an API/agent failure, possibly
    prefixed with the failing agent's name).
    """

    image: str
    error: str


@dataclass
class VariableScore:
    """Agreement for one variable over the rows where it was compared."""

    variable: str
    n: int
    n_agree: int
    # Cells keyed by (gold, predicted); None is a real category for is_upf,
    # and the pair is a slug rather than an int for food_category.
    confusion: dict[tuple[object, object], int] = field(default_factory=dict)

    @property
    def accuracy(self) -> float:
        return self.n_agree / self.n if self.n else 0.0

    @property
    def kappa(self) -> float:
        """Cohen's kappa: agreement corrected for what chance would give.

        Raw accuracy flatters an unbalanced set — if 90% of images are not ads,
        a model that always says 0 scores 0.90 while carrying no information.
        Returns 0.0 when chance agreement is total (one class only), where
        kappa is undefined and any nonzero value would be an artefact.
        """
        if not self.n:
            return 0.0
        gold_totals: dict[object, int] = {}
        pred_totals: dict[object, int] = {}
        for (gold, pred), count in self.confusion.items():
            gold_totals[gold] = gold_totals.get(gold, 0) + count
            pred_totals[pred] = pred_totals.get(pred, 0) + count
        expected = sum(
            gold_totals.get(label, 0) * pred_totals.get(label, 0)
            for label in set(gold_totals) | set(pred_totals)
        ) / (self.n * self.n)
        if expected >= 1.0:
            return 0.0
        return (self.accuracy - expected) / (1 - expected)


@dataclass
class GoldReport:
    model: str
    n_rows: int
    n_evaluated: int
    n_skipped_unlabelled: int
    n_skipped_disputed: int
    n_errors: int
    scores: dict[str, VariableScore]
    disagreements: list[Disagreement]
    errors: list[ScoringError]
    total_cost_usd: float = 0.0
    mode: str = ""
    # Whether the run that produced this report asked the model to justify
    # its labels. Carried through to the benchmark record because it is part
    # of how the numbers were produced, not a display preference.
    rationale: bool = False
    # Whether the run escalated to the audio channel when the visual/metadata
    # pass found no ad. Carried for the same reason as rationale: it is part
    # of how the numbers were produced.
    audio_escalation: bool = False
    # The speech-to-text model behind the transcripts, when escalation ran.
    stt_model: str = ""
    # Units where the audio channel was attempted but yielded nothing —
    # unreadable file, failed transcription, or no speech. Reported, never
    # scored: unlike n_errors these units still have complete primary labels.
    n_audio_errors: int = 0
    # Units the audio channel actually promoted to is_ad = 1. The one number
    # that says the flow did something rather than merely ran: escalations
    # can all come back negative, and then the score is identical to a run
    # with audio off.
    n_audio_flips: int = 0

    def as_dict(self) -> dict:
        return {
            "model": self.model,
            "mode": self.mode,
            "rationale": self.rationale,
            "audio_escalation": self.audio_escalation,
            "stt_model": self.stt_model,
            "n_audio_errors": self.n_audio_errors,
            "n_audio_flips": self.n_audio_flips,
            "n_rows": self.n_rows,
            "n_evaluated": self.n_evaluated,
            "n_skipped_unlabelled": self.n_skipped_unlabelled,
            "n_skipped_disputed": self.n_skipped_disputed,
            "n_errors": self.n_errors,
            "total_cost_usd": self.total_cost_usd,
            "scores": {
                name: {"n": s.n, "accuracy": s.accuracy, "kappa": s.kappa}
                for name, s in self.scores.items()
            },
            "disagreements": [
                {
                    "image": d.image, "variable": d.variable, "gold": d.gold,
                    "predicted": d.predicted, "rationale": d.rationale,
                    "model_rationale": d.model_rationale,
                }
                for d in self.disagreements
            ],
            "errors": [
                {"image": e.image, "error": e.error} for e in self.errors
            ],
        }


def _score(pairs: list[tuple[object, object]], variable: str) -> VariableScore:
    score = VariableScore(variable=variable, n=len(pairs), n_agree=0)
    for gold, predicted in pairs:
        if gold == predicted:
            score.n_agree += 1
        score.confusion[(gold, predicted)] = score.confusion.get((gold, predicted), 0) + 1
    return score


def score_predictions(
    rows: list[GoldRow],
    predictions: dict[str, dict],
    *,
    model: str = "",
    mode: str = "",
    total_cost_usd: float = 0.0,
    rationale: bool = False,
    audio_escalation: bool = False,
    stt_model: str = "",
) -> GoldReport:
    """Join predictions to gold by image filename and compute agreement.

    ``predictions`` maps image filename to a dict with is_ad/has_food/is_upf,
    and optionally ``error``. A row with no prediction, or whose prediction
    errored, is counted in n_errors and excluded from agreement — a failed API
    call is not evidence about the codebook and must not be scored as a miss.
    """
    usable = evaluable(rows)
    # food_category is scored alongside the binaries but is not in
    # LABEL_FIELDS — see GoldRow.food_category. Its "gold value" is "" when
    # unlabelled, which is why it is only compared where a category was coded.
    scored = SCORED_FIELDS
    pairs: dict[str, list[tuple[object, object]]] = {f: [] for f in scored}
    disagreements: list[Disagreement] = []
    errors: list[ScoringError] = []
    n_errors = 0

    for row in usable:
        prediction = predictions.get(row.image)
        if prediction is None or prediction.get("error"):
            n_errors += 1
            if prediction is None:
                errors.append(ScoringError(image=row.image, error="no prediction"))
            else:
                errors.append(ScoringError(image=row.image, error=prediction.get("error")))
            continue
        for variable in scored:
            gold_value = getattr(row, variable)
            predicted = prediction.get(variable)
            if variable == "food_category":
                # Only where the human actually coded a category. A blank gold
                # cell is "not yet coded", not "no category", so scoring it
                # would count every un-backfilled row as a model miss.
                if row.has_food != 1 or not gold_value:
                    continue
                predicted = predicted or ""
            # is_upf is only compared where the gold coding says food is present.
            # Comparing it under has_food=0 would just re-score has_food, since
            # _apply_labels forces is_upf to null there by construction.
            if variable == "is_upf" and row.has_food != 1:
                continue
            pairs[variable].append((gold_value, predicted))
            if gold_value != predicted:
                disagreements.append(Disagreement(
                    image=row.image, variable=variable, gold=gold_value,
                    predicted=predicted, rationale=row.rationale,
                    model_rationale=prediction.get(f"{variable}_reason") or "",
                ))

    return GoldReport(
        model=model,
        n_rows=len(rows),
        n_evaluated=len(usable) - n_errors,
        n_skipped_unlabelled=sum(1 for r in rows if not r.is_labelled),
        n_skipped_disputed=sum(1 for r in rows if r.disputed and r.is_labelled),
        n_errors=n_errors,
        scores={v: _score(p, v) for v, p in pairs.items()},
        disagreements=disagreements,
        errors=errors,
        total_cost_usd=total_cost_usd,
        mode=mode,
        rationale=rationale,
        audio_escalation=audio_escalation,
        stt_model=stt_model,
        n_audio_errors=sum(
            1 for row in usable
            if (predictions.get(row.image) or {}).get("audio_error")
        ),
        # The audio-escalation channel is disabled (see Config.audio_escalation)
        # and predictions no longer carry an `audio_is_ad` field to flip on —
        # that field named the retired flat is_ad, not any current ad
        # sub-flag. Hard-zeroed until a spoken-sponsorship sub-variable
        # revives an escalation channel to count flips for.
        n_audio_flips=0,
    )
