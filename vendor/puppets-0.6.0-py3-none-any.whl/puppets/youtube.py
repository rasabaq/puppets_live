"""YouTube Data API v3 client for gold-set provenance.

Only one endpoint is used — ``videos.list`` — and only to answer "what video
did these frames come from?". No search, no comments, no downloads. Metadata
never touches the labels: it is provenance, so a gold row can be traced back
to (and re-sampled from) its source video months later.

URL parsing is offline and unit-tested; only fetch_metadata needs the network.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass
from urllib.parse import parse_qs, urlparse

import requests

from .config import load_dotenv

logger = logging.getLogger(__name__)

API_URL = "https://www.googleapis.com/youtube/v3/videos"
COMMENTS_URL = "https://www.googleapis.com/youtube/v3/commentThreads"

# videos.list accepts up to 50 ids per call. Batching matters: a 200-row gold
# set is 4 calls instead of 200 against a quota'd API.
MAX_IDS_PER_CALL = 50

_VIDEO_ID = re.compile(r"^[A-Za-z0-9_-]{11}$")

# Paths whose first segment is the id: /embed/<id>, /shorts/<id>, /v/<id>, /live/<id>.
_ID_BEARING_PREFIXES = {"embed", "shorts", "v", "live"}


class YouTubeError(RuntimeError):
    pass


@dataclass(frozen=True)
class VideoMetadata:
    video_id: str
    title: str
    channel: str
    published_at: str
    duration: str
    view_count: str
    # Same `snippet` the existing call already returns — no extra quota.
    description: str = ""
    # Not a gold.csv column. Kept because fetch_uploader_comments needs it to
    # tell the uploader's own comments from everyone else's.
    channel_id: str = ""

    @classmethod
    def from_item(cls, item: dict) -> "VideoMetadata":
        snippet = item.get("snippet") or {}
        details = item.get("contentDetails") or {}
        statistics = item.get("statistics") or {}
        return cls(
            video_id=item.get("id", ""),
            title=snippet.get("title", ""),
            channel=snippet.get("channelTitle", ""),
            # RFC 3339, e.g. 2026-08-10T10:38:57Z. Kept verbatim rather than
            # reformatted, so the stored value is exactly what the API said.
            published_at=snippet.get("publishedAt", ""),
            duration=details.get("duration", ""),  # ISO 8601, e.g. PT4M13S
            view_count=str(statistics.get("viewCount", "")),
            description=snippet.get("description", ""),
            channel_id=snippet.get("channelId", ""),
        )


def video_id(url: str) -> str | None:
    """Extract the 11-character video id from a YouTube URL, or None.

    Accepts a bare id too, so a spreadsheet column that already holds ids
    needs no special-casing at the call site.
    """
    url = (url or "").strip()
    if not url:
        return None
    if _VIDEO_ID.match(url):
        return url
    # urlparse needs a scheme to see the host as a host rather than a path.
    parsed = urlparse(url if "//" in url else f"https://{url}")
    host = parsed.netloc.lower().removeprefix("www.").removeprefix("m.")

    if host == "youtu.be":
        candidate = parsed.path.lstrip("/").split("/")[0]
        return candidate if _VIDEO_ID.match(candidate) else None

    if not host.endswith("youtube.com"):
        return None

    watch = parse_qs(parsed.query).get("v", [""])[0]
    if _VIDEO_ID.match(watch):
        return watch

    segments = [s for s in parsed.path.split("/") if s]
    if len(segments) >= 2 and segments[0] in _ID_BEARING_PREFIXES:
        return segments[1] if _VIDEO_ID.match(segments[1]) else None
    return None


def uploader_comment(items: list[dict], channel_id: str) -> str:
    """The uploader's own top-level comment, or "" if they left none.

    The API exposes no "pinned" flag — nothing in the response marks one — so
    a pinned comment cannot be identified as such. What *is* reliable is
    authorship: this returns the first top-level comment whose author channel
    is the uploader's. Called on an ``order=relevance`` page, that is the
    pinned comment in the overwhelming majority of cases, because YouTube
    surfaces the pinned comment first. Treat the result as "something the
    uploader said", not as a guaranteed pin.

    A recipe posted by a viewer is deliberately excluded: it is not the
    uploader's claim about the food, so it is not provenance for this row.
    """
    if not channel_id:
        return ""
    for item in items:
        top_level = ((item.get("snippet") or {}).get("topLevelComment") or {})
        snippet = top_level.get("snippet") or {}
        author = (snippet.get("authorChannelId") or {}).get("value", "")
        if author and author == channel_id:
            # textOriginal is the raw text the author typed; textDisplay is
            # HTML with <a> and <br> injected, which would land in a CSV cell.
            return snippet.get("textOriginal", "") or snippet.get("textDisplay", "")
    return ""


def fetch_uploader_comments(videos: dict[str, str], api_key: str = "", *,
                            per_video: int = 20,
                            timeout: int = 30) -> dict[str, str]:
    """Fetch each uploader's own comment, keyed the same way ``videos`` is.

    ``videos`` maps any key you like (the gold row's url, typically) to that
    video's channel id — see VideoMetadata.channel_id. One API call per video:
    commentThreads has no batch-by-id form, unlike videos.list.

    Videos with comments disabled are skipped rather than raised on. That is a
    normal state for a video, not a failure of the fetch, and a whole run of
    500 videos must not die because one uploader turned comments off.
    """
    key = resolve_api_key(api_key)
    if not key:
        raise YouTubeError(
            "YOUTUBE_API_KEY is not set. Add it to .env (local) or Secrets (cloud)."
        )
    found: dict[str, str] = {}
    for reference, channel_id in videos.items():
        identifier = video_id(reference)
        if not identifier or not channel_id:
            continue
        response = requests.get(COMMENTS_URL, timeout=timeout, params={
            "part": "snippet",
            "videoId": identifier,
            # Relevance puts the pinned comment first; the default (time)
            # would put the oldest first and miss it entirely.
            "order": "relevance",
            "maxResults": max(1, min(per_video, 100)),
            "textFormat": "plainText",
            "key": key,
        })
        if response.status_code == 403:
            logger.warning("comments disabled for video %s", identifier)
            continue  # commentsDisabled — nothing to record for this video.
        if response.status_code != 200:
            raise YouTubeError(
                f"YouTube API returned {response.status_code} for comments on "
                f"{identifier}: {response.text[:300]}"
            )
        comment = uploader_comment(response.json().get("items", []), channel_id)
        if comment:
            found[reference] = comment
    logger.info(
        "fetched uploader comment for %d/%d video(s)", len(found), len(videos)
    )
    return found


def resolve_api_key(explicit: str = "") -> str:
    """Explicit key wins, then YOUTUBE_API_KEY from the environment / .env."""
    if explicit.strip():
        return explicit.strip()
    load_dotenv()
    return os.environ.get("YOUTUBE_API_KEY", "").strip()


def fetch_metadata(urls: list[str], api_key: str = "", *,
                   timeout: int = 30) -> dict[str, VideoMetadata]:
    """Look up every distinct video behind ``urls``.

    Returns a mapping keyed by the *input string* — url or bare id — so the
    caller can join results back to its own rows without re-parsing. Inputs
    that aren't YouTube URLs are skipped silently; a video that the API does
    not return (private, deleted, wrong id) is simply absent from the result,
    which the caller reports rather than filling in with blanks that would
    look like a successful fetch.
    """
    key = resolve_api_key(api_key)
    if not key:
        raise YouTubeError(
            "YOUTUBE_API_KEY is not set. Add it to .env (local) or Secrets (cloud)."
        )
    wanted = {url: found for url in urls if (found := video_id(url))}
    if not wanted:
        return {}

    ids = sorted(set(wanted.values()))
    by_id: dict[str, VideoMetadata] = {}
    for start in range(0, len(ids), MAX_IDS_PER_CALL):
        batch = ids[start:start + MAX_IDS_PER_CALL]
        response = requests.get(API_URL, timeout=timeout, params={
            "part": "snippet,contentDetails,statistics",
            "id": ",".join(batch),
            "key": key,
        })
        if response.status_code != 200:
            raise YouTubeError(
                f"YouTube API returned {response.status_code}: {response.text[:300]}"
            )
        for item in response.json().get("items", []):
            metadata = VideoMetadata.from_item(item)
            by_id[metadata.video_id] = metadata

    result = {url: by_id[found] for url, found in wanted.items() if found in by_id}
    logger.info("fetched metadata for %d/%d video(s)", len(result), len(wanted))
    return result
