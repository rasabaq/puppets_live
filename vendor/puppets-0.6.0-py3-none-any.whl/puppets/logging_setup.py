"""Logging setup for the "puppets" logger.

Configures the "puppets" logger specifically, not the root logger. Streamlit
installs its own root handler and re-runs app.py top-to-bottom on every
widget interaction, so configuring root would fight Streamlit, and letting
records propagate to root would double every line.
"""

from __future__ import annotations

import logging
import os
import sys

_LOGGER_NAME = "puppets"
_MARKER = "_puppets_setup"


def _resolve_level(level: str | int | None) -> int:
    if level is None:
        level = os.environ.get("PUPPETS_LOG_LEVEL", "INFO")
    if isinstance(level, int):
        return level
    name = str(level).strip().upper()
    resolved = logging.getLevelName(name)
    if isinstance(resolved, int):
        return resolved
    return logging.INFO


def setup_logging(level: str | int | None = None) -> None:
    """Configure the "puppets" logger with a single stderr handler.

    Idempotent: calling this repeatedly attaches exactly one handler. A
    repeat call with a different level updates the level on the existing
    logger and handler.
    """
    resolved_level = _resolve_level(level)
    logger = logging.getLogger(_LOGGER_NAME)
    logger.setLevel(resolved_level)
    logger.propagate = False

    existing = next(
        (h for h in logger.handlers if getattr(h, _MARKER, False)), None
    )
    if existing is not None:
        existing.setLevel(resolved_level)
        return

    handler = logging.StreamHandler(sys.stderr)
    handler.setLevel(resolved_level)
    handler.setFormatter(
        logging.Formatter(
            "%(asctime)s %(levelname)-7s %(name)s: %(message)s",
            datefmt="%H:%M:%S",
        )
    )
    setattr(handler, _MARKER, True)
    logger.addHandler(handler)
