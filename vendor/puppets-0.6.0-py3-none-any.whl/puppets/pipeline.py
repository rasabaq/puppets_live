"""Labelling pipeline: bundles of 1-20 screenshots in, labelled records out."""

from __future__ import annotations

import json
import logging
import time
import uuid
from concurrent.futures import Executor, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from . import agents
from .config import Config
from .openrouter import OpenRouterError, complete
from .schema import (
    AD_FIELDS,
    BRAND_NAME_MAX_CHARS,
    FOOD_CATEGORY_VALUES,
    FOOD_NAME_MAX_CHARS,
    LABEL_FIELDS,
    MAX_BRANDS,
    MAX_FOODS,
    REASON_FIELDS,
    SUPPRESSING_AD_FIELDS,
    UNDISCLOSED_FIELD,
)
from .trace import AGENT, ERROR, OK, SKIPPED, Step, UnitTrace

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class Bundle:
    """A unit of images to label, plus optional video metadata and audio.

    meta flows to every agent that opts into it (see agents.AgentSpec.
    uses_metadata and the per-variable metadata paragraphs in agents.py).
    Most bundles carry meta=None: every caller before this feature (and any
    upload with no title/description available) gets exactly today's prompts.

    audio is the video's audio track. It exists for API stability with
    upstream callers, but nothing in this module reads it today: the audio
    escalation channel it fed is disabled (Config.audio_escalation raises if
    enabled — see config.py) until a spoken-sponsorship ad sub-variable
    exists for it to feed.
    """

    images: list[Path]
    meta: "agents.VideoMeta | None" = None
    audio: Path | None = None


def _normalize_bundles(bundles: "list[list[Path]] | list[Bundle]") -> list[Bundle]:
    """Accept the plain list[list[Path]] every existing caller passes, a
    list[Bundle] with metadata attached, or a mix of the two — each entry is
    normalized independently, so a bare list of Paths becomes Bundle(images=...,
    meta=None), leaving a Bundle already in the list untouched."""
    return [b if isinstance(b, Bundle) else Bundle(images=list(b)) for b in bundles]


@dataclass
class LabelResult:
    """One labelled unit — a bundle of one image, or of many."""

    image_paths: list[str]
    bundle_id: str
    # One field per schema.AD_FIELDS member. Adding a sub-variable means
    # adding its field (and `_reason` counterpart) here by hand — dataclass
    # fields cannot be generated from a tuple — but every CONSUMER of these
    # fields (below, in _apply_labels, in any_ad, and in storage.CSV_COLUMNS)
    # loops over schema.AD_FIELDS / LABEL_FIELDS instead of naming a field,
    # so nothing past this declaration needs to change.
    #
    # ad_undisclosed is null (not 0) whenever any of the other three is 1 —
    # see schema.SUPPRESSING_AD_FIELDS and the suppression applied in
    # _label_agent_unit below.
    ad_paid_promotion: int | None = None
    ad_paid_advertising: int | None = None
    ad_brand_owned: int | None = None
    ad_undisclosed: int | None = None
    # undisclosed_agent's ACTUAL answer, kept from before suppression blanked
    # the field above. All four ad agents always run in parallel, so this
    # answer was asked for and paid for on every unit, suppressed ones
    # included; it is the only way to see whether undisclosed_agent over-fires
    # on units that already carry a disclosure. Recorded on every unit, not
    # only the suppressed ones — see _suppress_undisclosed for why.
    #
    # What it is NOT: a label. It is deliberately absent from
    # schema.AD_FIELDS, LABEL_FIELDS and REASON_FIELDS, so nothing scores it,
    # no gold column faces it, and any_ad() must never OR it in — ad_undisclosed
    # is already in that OR and its raw twin is the same agent's answer, which
    # would be counted twice. A diagnostic column, and nothing else.
    ad_undisclosed_raw: int | None = None
    has_food: int | None = None
    is_upf: int | None = None
    # The dietary food group, from category_agent. A string
    # enum, not a binary label, which is why it is not in schema.LABEL_FIELDS
    # — see the note there. null when has_food != 1, or when the food could
    # not be identified well enough to categorise.
    food_category: str | None = None
    # The brand or brands that paid for the promotion, from brand_agent.
    # A list, not a scalar, and not in schema.LABEL_FIELDS for the same
    # reason food_category is not — see the note there.
    #
    # Three states, all distinct and all meaningful: None means brand_agent
    # was never asked (any_ad(result) was False, or the agent errored); []
    # means the unit is advertising but no paying brand could be identified;
    # a non-empty
    # list names the payers, clearest first. Flattening [] into None would
    # lose the count of ads that are unattributable, which is itself a
    # finding about how disclosure works on the platform.
    brands: list[str] | None = None
    # The specific foods and drinks visible in the unit's frames, from
    # foods_agent. Modelled on brands: a list, not a scalar, not in
    # schema.LABEL_FIELDS for the same reason, and the same three states —
    # None means foods_agent was never asked (has_food != 1, or the agent
    # errored); [] means food is present but could not be named specifically
    # enough; a non-empty list names the items, most prominent first. Unlike
    # brands, mere on-screen presence is the qualifying criterion — see
    # schema.FOODS_DEFINITION.
    foods: list[str] | None = None
    # Populated only when the run has rationale enabled (Config.rationale);
    # None on a default run, which is why they are not in LABEL_FIELDS and
    # nothing downstream may treat them as labels.
    ad_paid_promotion_reason: str | None = None
    ad_paid_advertising_reason: str | None = None
    ad_brand_owned_reason: str | None = None
    ad_undisclosed_reason: str | None = None
    has_food_reason: str | None = None
    is_upf_reason: str | None = None
    food_category_reason: str | None = None
    brands_reason: str | None = None
    foods_reason: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    generation_id: str | None = None
    error: str | None = None
    # Audio-channel fields, kept for CSV/API stability while the channel is
    # disabled (see Config.audio_escalation) — every run leaves these at
    # their default. They will carry meaning again once a spoken-sponsorship
    # ad sub-variable is added and the escalation channel is rebuilt to
    # target it.
    audio_error: str | None = None
    audio_cost_usd: float = 0.0
    raw_response: dict | None = field(default=None, repr=False)
    # How this unit reached its labels: which agent set what, which gates
    # fired, what each call cost. Populated on every run (building it is a
    # few dataclasses, not an API call); dropped from as_row so the CSV is
    # unchanged, and persisted separately by the benchmark. See trace.py.
    trace: "UnitTrace | None" = field(default=None, repr=False)

    @property
    def n_images(self) -> int:
        return len(self.image_paths)

    def as_row(self) -> dict:
        row = asdict(self)
        row.pop("raw_response")
        row.pop("trace")
        return row


def _coerce_label(value: object) -> int | None:
    """Return 0/1, or None for anything else.

    The JSON schema cannot pin these to {0, 1} — see the note in schema.py —
    so an out-of-range value is treated as missing rather than recorded as data.
    """
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int) and value in (0, 1):
        return value
    return None


def _coerce_category(value: object) -> str | None:
    """Return one of schema.FOOD_CATEGORY_VALUES, or None.

    The response schema does pin this with an enum (a string property, which
    Gemini's validator accepts), but the check is repeated here for the same
    reason _coerce_label exists: a value that is not in the codebook is
    treated as missing rather than recorded as data, whatever the API let
    through.
    """
    if isinstance(value, str) and value in FOOD_CATEGORY_VALUES:
        return value
    return None


def _coerce_brands(value: object) -> list[str] | None:
    """Return a clean list of at most MAX_BRANDS brand names, or None.

    None is returned only for a value that is not a list at all — a malformed
    response, which is "no answer" and not "no brands". An empty list that
    the model actually sent survives as an empty list, because for this
    variable that is a real answer (see LabelResult.brands).

    Entries are stripped, de-duplicated case-insensitively while keeping the
    model's ordering and its original casing, and dropped if empty, too long
    to be a name (BRAND_NAME_MAX_CHARS — see the note there on prose creeping
    into a free-text field), or not a string. Dropped rather than repaired:
    a value that is not a brand name should not be recorded as one.
    """
    if not isinstance(value, list):
        return None
    out: list[str] = []
    seen: set[str] = set()
    for item in value:
        if not isinstance(item, str):
            continue
        name = item.strip().lstrip("@").strip()
        if not name or len(name) > BRAND_NAME_MAX_CHARS:
            continue
        key = name.casefold()
        if key in seen:
            continue
        seen.add(key)
        out.append(name)
        if len(out) == MAX_BRANDS:
            break
    return out


def _coerce_foods(value: object) -> list[str] | None:
    """Return a clean list of at most MAX_FOODS food names, or None.

    Mirrors _coerce_brands exactly, including why: None is returned only for
    a value that is not a list at all — a malformed response, which is "no
    answer" and not "no foods". An empty list that the model actually sent
    survives as an empty list, because for this variable that is a real
    answer (see LabelResult.foods).

    Entries are stripped and dropped if empty, too long to be a name
    (FOOD_NAME_MAX_CHARS — see the note there on prose creeping into a
    free-text field), or not a string. Dropped rather than repaired: a value
    that is not a food name should not be recorded as one.
    """
    if not isinstance(value, list):
        return None
    out: list[str] = []
    for item in value:
        if not isinstance(item, str):
            continue
        name = item.strip()
        if not name or len(name) > FOOD_NAME_MAX_CHARS:
            continue
        out.append(name)
        if len(out) == MAX_FOODS:
            break
    return out


def _coerce_reason(value: object) -> str | None:
    """Return a non-empty stripped string, or None.

    An empty or whitespace-only reason is recorded as absent rather than as
    an empty string, so "the model gave no reason" and "rationale was off for
    this run" read the same downstream instead of being two near-identical
    states to handle.
    """
    if not isinstance(value, str):
        return None
    return value.strip() or None


def _suppress_undisclosed(result: LabelResult) -> None:
    """Null out ad_undisclosed once another ad flag is 1, keeping the answer.

    ad_undisclosed means "commercial intent with no disclosure". Once any of
    schema.SUPPRESSING_AD_FIELDS is 1 the unit already has a disclosure or a
    stated ownership relationship, so the question is not applicable — null,
    distinct from 0 ("asked, and no trigger found"). Suppression only ever
    turns ad_undisclosed itself into None; it never changes any other field,
    so any_ad(result) is unaffected by where this runs relative to it.

    What the agent actually answered is preserved in ad_undisclosed_raw rather
    than destroyed, and ad_undisclosed_reason is now left alone for the same
    reason: undisclosed_agent runs on every unit regardless (all four ad
    agents go out in parallel), so that answer and its justification are
    already bought, and they are how a reader finds out the agent is
    over-firing. The reason explains the answer in ad_undisclosed_raw, which
    is still on the record — it is no longer a justification for a value that
    has been erased.

    ad_undisclosed_raw is recorded on EVERY unit, not only the suppressed
    ones. A reader diffing the two columns must be able to read an empty raw
    cell as one thing only — "the agent gave no usable answer". Filling it
    only on suppression would make an empty cell mean that on some rows and
    "this row was not suppressed" on others, and the diff would mislead.
    """
    # `is not None` keeps this idempotent: a second pass would otherwise copy
    # the None the first pass wrote over the answer the first pass recorded.
    # No hasattr guard: video_testing/pipeline.py shares this function with
    # its own VideoLabelResult, which declares the raw field too, so both
    # record the answer their preserved reason justifies. A type that ever
    # arrives here without the field should raise rather than silently drop
    # the answer on the floor.
    if result.ad_undisclosed is not None:
        result.ad_undisclosed_raw = result.ad_undisclosed
    if any(getattr(result, f) == 1 for f in SUPPRESSING_AD_FIELDS):
        result.ad_undisclosed = None


def _missing_required_fields(result: LabelResult) -> list[str]:
    """Ad/has_food fields with no usable value — a genuine model failure.

    ad_undisclosed is excluded exactly when it was deliberately suppressed to
    None by the asymmetry above: that None means "not applicable", not "the
    model returned nothing usable", and must not be reported as a missing
    value by either call site (_apply_labels below, and the run-level check
    in _label_agent_unit).
    """
    suppressed = any(getattr(result, f) == 1 for f in SUPPRESSING_AD_FIELDS)
    return [
        f for f in (*AD_FIELDS, "has_food")
        if getattr(result, f) is None and not (suppressed and f == UNDISCLOSED_FIELD)
    ]


def _apply_labels(result: LabelResult, labels: dict) -> None:
    for field_name in LABEL_FIELDS:
        setattr(result, field_name, _coerce_label(labels.get(field_name)))
    for field_name in REASON_FIELDS:
        setattr(result, field_name, _coerce_reason(labels.get(field_name)))
    # Enforce the measurement rule the schema can only ask for politely.
    if result.has_food == 0:
        result.is_upf = None
        # The is_upf reason goes with it: keeping a justification for a label
        # that was just overridden to null would be a record of a judgement
        # the run did not actually make.
        result.is_upf_reason = None
        # Same rule, same reason, for the category: a food category recorded
        # against a unit the run decided has no food is not a judgement the
        # run made.
        result.food_category = None
        result.food_category_reason = None
    _suppress_undisclosed(result)
    missing = _missing_required_fields(result)
    if missing:
        result.error = f"Model returned no usable value for: {', '.join(missing)}"


def any_ad(result: LabelResult) -> bool:
    """True if any ad sub-flag is 1 — the sole place the OR over AD_FIELDS
    lives. There is no stored, derived `is_ad`: every gate that used to read
    `result.is_ad == 1` (brand_agent's gate, trace conditions, logging) calls
    this instead, so adding an ad sub-variable never means finding another
    place that quietly assumed there was exactly one ad flag.
    """
    return any(getattr(result, f) == 1 for f in AD_FIELDS)


@dataclass
class _AgentCallResult:
    """The outcome of one focused agent's API call."""

    value: object = None
    reason: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    generation_id: str | None = None
    raw: dict | None = None
    error: str | None = None
    # Wall-clock for this one call. Latency is per-agent, and a trace that
    # could not say which agent is the slow one would not explain a run's
    # duration.
    duration_seconds: float = 0.0


def _stamp(call: "_AgentCallResult", started: float) -> "_AgentCallResult":
    """Record how long a call took, on every exit path."""
    call.duration_seconds = round(time.monotonic() - started, 3)
    return call


def _run_agent(cfg: Config, spec: "agents.AgentSpec", images: list[Path],
               meta: "agents.VideoMeta | None" = None,
               transcript: str | None = None) -> _AgentCallResult:
    call = _AgentCallResult()
    started = time.monotonic()
    try:
        # meta and transcript are both passed to every spec uniformly here —
        # it is spec.uses_metadata / spec.uses_transcript that decides whether
        # either reaches the prompt. transcript is None for every caller but
        # the brand_agent stage, and brand_agent is the only spec that opts in.
        # meta is passed to every spec uniformly here — it is spec.uses_metadata
        # that decides whether it reaches the prompt, and which of the spec's
        # two system-prompt variants and which evidence clause it gets. All
        # three specs opt in today; a spec that did not would be unaffected.
        completion = complete(
            cfg,
            images=images,
            system_prompt=spec.system_prompt_for(meta=meta, reason=cfg.rationale),
            user_text=spec.user_text(n_images=len(images), meta=meta,
                                     transcript=transcript),
            response_format=spec.schema_for(reason=cfg.rationale),
            model=cfg.model_for_agent(spec.name),
        )
    except OpenRouterError as exc:
        call.error = str(exc)
        logger.exception("%s call failed: %s", spec.name, exc)
        return _stamp(call, started)

    call.prompt_tokens = completion.usage.prompt_tokens
    call.completion_tokens = completion.usage.completion_tokens
    call.cost_usd = completion.usage.cost_usd
    call.generation_id = completion.generation_id
    call.raw = completion.raw
    try:
        parsed = completion.parsed()
        call.value = parsed.get(spec.field)
        call.reason = _coerce_reason(parsed.get(spec.reason_field))
    except OpenRouterError as exc:
        call.error = str(exc)
        logger.exception("%s returned unparsable response: %s", spec.name, exc)
    return _stamp(call, started)


def _agent_step(step_id: str, call: _AgentCallResult, *,
                kind: str = AGENT, variable: str | None = None,
                model: str = "", inputs: "list[str] | None" = None,
                condition: str = "", value: object = None) -> Step:
    """One agent call, as a trace step. Status comes from the call itself."""
    return Step(
        id=step_id,
        kind=kind,
        label=step_id,
        variable=variable,
        value=value if call.error is None else None,
        reason=call.reason,
        status=ERROR if call.error else OK,
        error=call.error,
        model=model,
        prompt_tokens=call.prompt_tokens,
        completion_tokens=call.completion_tokens,
        cost_usd=call.cost_usd,
        duration_seconds=call.duration_seconds,
        inputs=list(inputs or []),
        condition=condition,
    )


def _merge_agent_call(result: LabelResult, name: str, call: _AgentCallResult,
                       gen_ids: dict, raws: dict) -> None:
    result.prompt_tokens += call.prompt_tokens
    result.completion_tokens += call.completion_tokens
    result.cost_usd += call.cost_usd
    if call.generation_id is not None:
        gen_ids[name] = call.generation_id
    if call.raw is not None:
        raws[name] = call.raw


def _label_agent_unit(cfg: Config, pool: Executor, images: list[Path],
                       bundle_id: str,
                       meta: "agents.VideoMeta | None" = None,
                       audio: Path | None = None) -> tuple[LabelResult, int, bool]:
    """Label one unit (a bundle of one image, or of many) with the agent flow.

    Every agents.AD_AGENTS entry and food_agent run concurrently on `pool`;
    upf_agent and category_agent then run concurrently with each other, only
    if has_food == 1 and only after food_agent is known to have succeeded.
    brand_agent runs last, alone, only if any_ad(result) is true.

    `meta` is handed to every metadata-aware agent's _run_agent call below,
    and each folds it into its own prompt using its own metadata paragraph.
    A bundle with meta=None leaves every prompt at its base variant, so a run
    over metadata-less units is unaffected.

    The third return value (`escalated`) is always False today: the audio
    escalation channel is disabled (see Config.audio_escalation). It stays in
    the return shape so callers do not need to change again once a
    spoken-sponsorship sub-variable revives it.
    """
    result = LabelResult(image_paths=[str(p) for p in images], bundle_id=bundle_id)
    trace = UnitTrace(
        unit_id=bundle_id,
        unit_label=" | ".join(Path(p).name for p in images),
        mode=cfg.mode,
        model=cfg.model,
    )
    result.trace = trace
    gen_ids: dict[str, str] = {}
    raws: dict[str, dict] = {}
    n_calls = 0
    started = time.monotonic()
    logger.info("labelling bundle %s: %d image(s)", bundle_id, len(images))

    ad_futures = {
        spec.field: pool.submit(_run_agent, cfg, spec, images, meta)
        for spec in agents.AD_AGENTS
    }
    food_future = pool.submit(_run_agent, cfg, agents.FOOD_AGENT, images, meta)
    ad_calls = {field: future.result() for field, future in ad_futures.items()}
    food_call = food_future.result()
    n_calls += len(ad_calls) + 1
    for spec in agents.AD_AGENTS:
        call = ad_calls[spec.field]
        _merge_agent_call(result, spec.name, call, gen_ids, raws)
        trace.add(_agent_step(
            spec.name, call, variable=spec.field,
            model=cfg.model_for_agent(spec.name),
            value=_coerce_label(call.value),
        ))
    _merge_agent_call(result, agents.FOOD_AGENT.name, food_call, gen_ids, raws)
    trace.add(_agent_step(
        agents.FOOD_AGENT.name, food_call, variable="has_food",
        model=cfg.model_for_agent(agents.FOOD_AGENT.name),
        value=_coerce_label(food_call.value),
    ))

    errors = []
    if food_call.error:
        errors.append(f"{agents.FOOD_AGENT.name}: {food_call.error}")
        result.error = "; ".join(errors)
        result.generation_id = json.dumps(gen_ids) if gen_ids else None
        result.raw_response = raws or None
        trace.error = result.error
        trace.labels = {f: getattr(result, f) for f in LABEL_FIELDS}
        logger.warning(
            "bundle %s aborted after %.1fs: %s",
            bundle_id, time.monotonic() - started, result.error,
        )
        return result, n_calls, False
    for spec in agents.AD_AGENTS:
        call = ad_calls[spec.field]
        if call.error:
            errors.append(f"{spec.name}: {call.error}")

    for spec in agents.AD_AGENTS:
        call = ad_calls[spec.field]
        setattr(result, spec.field, _coerce_label(call.value))
        setattr(result, spec.reason_field, call.reason)
    # Suppress ad_undisclosed before any_ad(result) is used to gate
    # brand_agent below. This is safe from a cycle: suppression only ever
    # turns ad_undisclosed from a value into None when another ad flag is
    # already 1, so any_ad(result) is True either way and the brand gate
    # below sees the same answer whether this runs before or after it.
    _suppress_undisclosed(result)
    result.has_food = _coerce_label(food_call.value)
    result.has_food_reason = food_call.reason

    if result.has_food == 1:
        # Submitted together, joined together. category_agent and foods_agent
        # are each independent of is_upf by design (see
        # FOOD_CATEGORY_DEFINITION and FOODS_DEFINITION), so nothing here
        # needs upf_agent's answer — running them concurrently keeps a
        # food-positive unit at the same wall-clock as when upf_agent was the
        # only second-stage call.
        upf_future = pool.submit(_run_agent, cfg, agents.UPF_AGENT, images, meta)
        category_future = pool.submit(
            _run_agent, cfg, agents.CATEGORY_AGENT, images, meta)
        foods_future = pool.submit(
            _run_agent, cfg, agents.FOODS_AGENT, images, meta)
        upf_call = upf_future.result()
        category_call = category_future.result()
        foods_call = foods_future.result()
        n_calls += 3
        _merge_agent_call(result, agents.UPF_AGENT.name, upf_call, gen_ids, raws)
        _merge_agent_call(
            result, agents.CATEGORY_AGENT.name, category_call, gen_ids, raws)
        _merge_agent_call(result, agents.FOODS_AGENT.name, foods_call, gen_ids, raws)
        trace.add(_agent_step(
            agents.UPF_AGENT.name, upf_call, variable="is_upf",
            model=cfg.model_for_agent(agents.UPF_AGENT.name),
            value=_coerce_label(upf_call.value),
            inputs=[agents.FOOD_AGENT.name], condition="has_food = 1",
        ))
        trace.add(_agent_step(
            agents.CATEGORY_AGENT.name, category_call, variable="food_category",
            model=cfg.model_for_agent(agents.CATEGORY_AGENT.name),
            value=_coerce_category(category_call.value),
            inputs=[agents.FOOD_AGENT.name], condition="has_food = 1",
        ))
        trace.add(_agent_step(
            agents.FOODS_AGENT.name, foods_call, variable="foods",
            model=cfg.model_for_agent(agents.FOODS_AGENT.name),
            value=_coerce_foods(foods_call.value),
            inputs=[agents.FOOD_AGENT.name], condition="has_food = 1",
        ))
        if upf_call.error:
            errors.append(f"{agents.UPF_AGENT.name}: {upf_call.error}")
        else:
            result.is_upf = _coerce_label(upf_call.value)
            result.is_upf_reason = upf_call.reason
        # A failed category_agent is recorded and moved past, not fatal: it
        # is an added descriptive field, and losing it must not cost the run
        # the ad-flag/has_food/is_upf labels the audit is actually built on.
        if category_call.error:
            errors.append(f"{agents.CATEGORY_AGENT.name}: {category_call.error}")
        else:
            result.food_category = _coerce_category(category_call.value)
            result.food_category_reason = category_call.reason
        # Same rule, same reason, for foods_agent.
        if foods_call.error:
            errors.append(f"{agents.FOODS_AGENT.name}: {foods_call.error}")
        else:
            result.foods = _coerce_foods(foods_call.value)
            result.foods_reason = foods_call.reason
    else:
        # upf_agent never ran, so there is no is_upf_reason to record — the
        # null here is "not asked", matching is_upf itself.
        result.is_upf = None
        # Recorded as a skipped step rather than omitted: "upf_agent was never
        # asked" and "this run has no upf_agent" are different facts, and only
        # the first one explains a null is_upf.
        trace.add(Step(
            id=agents.UPF_AGENT.name, kind=AGENT, label=agents.UPF_AGENT.name,
            variable="is_upf", status=SKIPPED,
            inputs=[agents.FOOD_AGENT.name],
            condition=f"has_food = {result.has_food}",
        ))
        result.food_category = None
        trace.add(Step(
            id=agents.CATEGORY_AGENT.name, kind=AGENT,
            label=agents.CATEGORY_AGENT.name,
            variable="food_category", status=SKIPPED,
            inputs=[agents.FOOD_AGENT.name],
            condition=f"has_food = {result.has_food}",
        ))
        result.foods = None
        trace.add(Step(
            id=agents.FOODS_AGENT.name, kind=AGENT,
            label=agents.FOODS_AGENT.name,
            variable="foods", status=SKIPPED,
            inputs=[agents.FOOD_AGENT.name],
            condition=f"has_food = {result.has_food}",
        ))

    # The audio channel is disabled in this pass — Config.audio_escalation
    # raises if set, so `audio` is never acted on here. `escalated` stays
    # False so the return shape and RunSummary.n_escalations do not need to
    # change again once a spoken-sponsorship sub-variable revives the channel.
    escalated = False

    # brand_agent. Last of all, and gated on any_ad(result) — true if any ad
    # sub-flag is 1. Once the audio channel is revived, that gate is exactly
    # where a spoken-disclosure sub-flag would join AD_FIELDS and get picked
    # up here automatically, with no change to this condition.
    ad_agent_names = [spec.name for spec in agents.AD_AGENTS]
    if any_ad(result):
        brand_call = _run_agent(cfg, agents.BRAND_AGENT, images, meta)
        n_calls += 1
        _merge_agent_call(result, agents.BRAND_AGENT.name, brand_call, gen_ids, raws)
        trace.add(_agent_step(
            agents.BRAND_AGENT.name, brand_call, variable="brands",
            model=cfg.model_for_agent(agents.BRAND_AGENT.name),
            value=_coerce_brands(brand_call.value),
            inputs=ad_agent_names, condition="any ad sub-flag = 1",
        ))
        # Recorded and moved past, never fatal — the same rule category_agent
        # gets, and for the same reason: brands is a descriptive field added
        # on top of the audit's core labels, and losing it must not cost the
        # unit its ad-flags/has_food/is_upf.
        if brand_call.error:
            errors.append(f"{agents.BRAND_AGENT.name}: {brand_call.error}")
        else:
            result.brands = _coerce_brands(brand_call.value)
            result.brands_reason = brand_call.reason
    else:
        # Left as None — "not asked" — and recorded as a skipped step, so a
        # null here is explained by the gate rather than looking like an
        # agent that returned nothing. Distinct from the [] that a unit which
        # IS advertising gets when no payer could be named.
        result.brands = None
        trace.add(Step(
            id=agents.BRAND_AGENT.name, kind=AGENT,
            label=agents.BRAND_AGENT.name,
            variable="brands", status=SKIPPED,
            inputs=ad_agent_names,
            condition="no ad sub-flag = 1",
        ))

    missing = _missing_required_fields(result)
    if missing:
        errors.append(f"Model returned no usable value for: {', '.join(missing)}")
    if errors:
        result.error = "; ".join(errors)

    result.generation_id = json.dumps(gen_ids) if gen_ids else None
    result.raw_response = raws or None
    trace.error = result.error
    trace.labels = {f: getattr(result, f) for f in LABEL_FIELDS}
    logger.info(
        "bundle %s labelled in %.1fs: %s has_food=%s is_upf=%s "
        "food_category=%s brands=%s foods=%s cost=$%.4f%s",
        bundle_id, time.monotonic() - started,
        " ".join(f"{f}={getattr(result, f)}" for f in AD_FIELDS),
        result.has_food, result.is_upf, result.food_category, result.brands,
        result.foods, result.cost_usd,
        " (with errors)" if result.error else "",
    )
    return result, n_calls, escalated


@dataclass
class RunSummary:
    run_id: str
    model: str
    mode: str
    bundle_size: int
    started_at: str
    finished_at: str
    n_images: int
    n_label_sets: int
    n_errors: int
    n_api_calls: int
    total_cost_usd: float
    mean_cost_per_image_usd: float
    mean_cost_per_call_usd: float
    total_prompt_tokens: int
    total_completion_tokens: int
    # How many units escalated to the audio channel, and what that cost.
    # Always 0 while the channel is disabled (see Config.audio_escalation).
    #
    # Defaulted and placed last so that constructing a RunSummary without
    # them — every caller that predates audio escalation — still works.
    n_escalations: int = 0
    audio_cost_usd: float = 0.0


def run(cfg: Config,
        bundles: "list[list[Path]] | list[Bundle]") -> tuple[list[LabelResult], RunSummary]:
    """Label every bundle and return per-call results plus a run summary.

    `bundles` accepts a plain list[list[Path]] — what every existing caller
    passes — a list[Bundle] carrying per-video metadata, or a mix of both;
    see Bundle and _normalize_bundles.
    """
    bundles = _normalize_bundles(bundles)
    run_id = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:6]}"
    started_at = datetime.now(timezone.utc).isoformat()
    started_monotonic = time.monotonic()
    results: list[LabelResult] = []
    n_api_calls = 0
    n_escalations = 0
    logger.info(
        "run %s starting: %d bundle(s), model=%s, mode=%s",
        run_id, len(bundles), cfg.model, cfg.mode,
    )

    # One unit per bundle, always. A caller that wants a verdict per
    # image passes bundles of one image — which is exactly what the
    # removed agent_per_image mode produced, minus a second code path
    # that had to re-derive it here.
    units = [
        (f"{run_id}-b{position:04d}", bundle.images, bundle.meta, bundle.audio)
        for position, bundle in enumerate(bundles, start=1)
    ]

    # Two pools, not one. `agent_pool` is capped at cfg.max_workers and is
    # the *only* place a real HTTP call happens (inside _run_agent) — it
    # is the sole gate on concurrent API traffic. `unit_pool` exists only
    # to orchestrate units in parallel: each of its threads runs
    # _label_agent_unit, which submits 2-3 futures to agent_pool and
    # blocks on `.result()`. That block is pure I/O wait, not agent_pool
    # work, so unit_pool threads never occupy an agent_pool slot.
    #
    # This is deadlock-free by construction: a pool worker only ever
    # deadlocks by blocking on a future that needs a slot in its *own*
    # pool (all workers busy waiting on each other with no one left to
    # run the submitted task). Here unit_pool threads block on futures
    # submitted to agent_pool, never to unit_pool itself, and agent_pool
    # threads (_run_agent) never submit anything anywhere — they only
    # make an HTTP call and return. So there is no cycle in which a
    # worker waits on its own pool's capacity.
    #
    # unit_pool is sized generously (bounded only to avoid an absurd
    # thread count) because oversizing it just creates more threads that
    # sit blocked on I/O; it enforces no concurrency limit of its own.
    # The real ceiling — actual concurrent HTTP calls — comes entirely
    # from agent_pool's max_workers cap.
    unit_workers = max(1, min(len(units), max(cfg.max_workers * 4, 32)))
    with ThreadPoolExecutor(max_workers=cfg.max_workers) as agent_pool, \
            ThreadPoolExecutor(max_workers=unit_workers) as unit_pool:
        futures = [
            unit_pool.submit(_label_agent_unit, cfg, agent_pool, images,
                             bundle_id, meta, audio)
            for bundle_id, images, meta, audio in units
        ]
        for future in futures:
            result, n_calls, escalated = future.result()
            results.append(result)
            n_api_calls += n_calls
            n_escalations += int(escalated)
    total_cost = sum(r.cost_usd for r in results)
    n_images = sum(r.n_images for r in results)
    summary = RunSummary(
        run_id=run_id,
        model=cfg.model,
        mode=cfg.mode,
        bundle_size=max((len(b.images) for b in bundles), default=0),
        started_at=started_at,
        finished_at=datetime.now(timezone.utc).isoformat(),
        n_images=n_images,
        n_label_sets=len(results),
        n_errors=sum(1 for r in results if r.error),
        n_api_calls=n_api_calls,
        total_cost_usd=total_cost,
        n_escalations=n_escalations,
        audio_cost_usd=sum(r.audio_cost_usd for r in results),
        mean_cost_per_image_usd=total_cost / n_images if n_images else 0.0,
        mean_cost_per_call_usd=total_cost / n_api_calls if n_api_calls else 0.0,
        total_prompt_tokens=sum(r.prompt_tokens for r in results),
        total_completion_tokens=sum(r.completion_tokens for r in results),
    )
    logger.info(
        "run %s finished in %.1fs: %d label set(s), %d error(s), %d api call(s), "
        "cost=$%.4f",
        run_id, time.monotonic() - started_monotonic, len(results),
        summary.n_errors, n_api_calls, total_cost,
    )
    return results, summary
