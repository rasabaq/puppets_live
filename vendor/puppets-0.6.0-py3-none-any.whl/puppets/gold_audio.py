"""Download the audio track of a gold row's source video with yt-dlp.

Shared core behind ``scripts/fetch_gold_audio.py`` and the gold builder app's
Audio section. One file per *video*, named after the YouTube id, written to
tests/fixtures/gold/audio/ (or whatever directory the caller passes).

The output is mono m4a at a low bitrate: speech survives it, and the payload
is base64'd into a JSON request body, so size is the thing that actually
breaks (see puppets.audio.MAX_AUDIO_BYTES).

Needs yt-dlp and ffmpeg on the path (or yt-dlp in the venv: pip install yt-dlp).
"""

from __future__ import annotations

import logging
import shutil
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger(__name__)

# Mono, 32 kbps AAC. A 60-second Short lands around 250 KB, well inside the
# 20 MB ceiling, and speech-to-text does not benefit from more.
BITRATE = "32k"
SUFFIX = ".m4a"


class AudioFetchError(RuntimeError):
    """yt-dlp (or ffmpeg, its postprocessor) is unusable — not a per-video
    download failure, but a missing-tool problem the caller should surface
    to a human instead of retrying."""


@dataclass
class AudioFetchResult:
    """Outcome of fetching audio for every distinct video in a batch."""

    done: dict[str, str]     # video id -> filename
    failed: dict[str, str]   # video id -> error string


def yt_dlp_command() -> list[str]:
    """Prefer the yt-dlp binary; fall back to the module in this interpreter."""
    binary = shutil.which("yt-dlp")
    if binary:
        return [binary]
    return [sys.executable, "-m", "yt_dlp"]


def tools_available() -> str | None:
    """None if yt-dlp and ffmpeg are both usable; otherwise a message saying
    which is missing, meant to be shown directly in a UI."""
    if not shutil.which("yt-dlp") and shutil.which(sys.executable):
        # Fall back check: is the yt_dlp module importable?
        try:
            __import__("yt_dlp")
        except ImportError:
            return "yt-dlp is not installed. Run `pip install yt-dlp`."
    if not shutil.which("ffmpeg"):
        return "ffmpeg is not on the PATH. Audio extraction needs it to convert to m4a."
    return None


def download(url: str, out_path: Path, *, downloader=None) -> str | None:
    """Fetch the audio track to out_path. Returns an error string, or None.

    ``downloader`` is injectable for tests: a callable(command) -> CompletedProcess-like
    object, so no real subprocess or network is needed to exercise the logic here.
    """
    command = yt_dlp_command() + [
        "--quiet", "--no-warnings", "--no-playlist",
        "-f", "bestaudio/best",
        "--extract-audio", "--audio-format", "m4a",
        # Downmix to mono at a low bitrate — this is the size lever.
        "--postprocessor-args", f"ExtractAudio:-ac 1 -b:a {BITRATE}",
        # yt-dlp appends the extension itself, so hand it the stem.
        "-o", str(out_path.with_suffix("")) + ".%(ext)s",
        url,
    ]
    logger.info("fetching audio for %s", url)
    runner = downloader or (lambda cmd: subprocess.run(cmd, capture_output=True, text=True))
    result = runner(command)
    if result.returncode != 0:
        lines = (result.stderr or result.stdout).strip().splitlines()
        error = lines[-1] if lines else "yt-dlp failed"
        logger.warning("audio fetch failed for %s: %s", url, error)
        return error
    if not out_path.exists():
        error = f"yt-dlp reported success but {out_path.name} is missing"
        logger.warning("audio fetch failed for %s: %s", url, error)
        return error
    logger.info("fetched audio for %s -> %s", url, out_path.name)
    return None


def videos_needing_audio(rows, video_id_fn) -> dict[str, str]:
    """One entry per distinct video id among ``rows`` that has a usable url,
    mapping video id -> url. Rows sharing a video id collapse to one entry —
    a bundle's frames share a video, so only one download is needed.

    ``video_id_fn`` extracts the id from a url string (e.g. youtube.video_id).
    """
    wanted: dict[str, str] = {}
    for row in rows:
        url = (row.url or "").strip()
        vid = video_id_fn(url)
        if vid:
            wanted.setdefault(vid, url)
    return wanted


def fetch_audio(wanted: dict[str, str], audio_dir: Path, *,
                force: bool = False, limit: int | None = None,
                downloader=None) -> AudioFetchResult:
    """Download audio for every video id in ``wanted`` not already on disk.

    A file already at ``audio_dir/<id>.m4a`` is treated as done and skipped,
    unless ``force`` is set. Raises AudioFetchError if the required tooling
    is missing — call ``tools_available()`` first to get a UI-friendly
    message instead of an exception.
    """
    if downloader is None:
        missing = tools_available()
        if missing:
            raise AudioFetchError(missing)

    audio_dir.mkdir(parents=True, exist_ok=True)
    done: dict[str, str] = {}
    failed: dict[str, str] = {}
    downloads = 0
    for vid, url in wanted.items():
        out_path = audio_dir / f"{vid}{SUFFIX}"
        if out_path.exists() and not force:
            done[vid] = out_path.name
            continue
        if limit is not None and downloads >= limit:
            continue
        error = download(url, out_path, downloader=downloader)
        downloads += 1
        if error:
            failed[vid] = error
        else:
            done[vid] = out_path.name
    logger.info(
        "audio fetch complete: %d done, %d failed", len(done), len(failed)
    )
    return AudioFetchResult(done=done, failed=failed)
