"""Thin OpenRouter chat-completions client with usage/cost accounting."""

from __future__ import annotations

import json
import logging
import random
import time
from dataclasses import dataclass, field
from pathlib import Path

import requests

from .audio import audio_format, to_input_audio_part
from .config import OPENROUTER_URL, TRANSCRIPTIONS_URL, Config
from .images import to_data_url

logger = logging.getLogger(__name__)

RETRYABLE_STATUS = {408, 409, 429, 500, 502, 503, 504}


class OpenRouterError(RuntimeError):
    pass


@dataclass
class Usage:
    """Token counts and cost for one API call, as reported by OpenRouter."""

    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cost_usd: float = 0.0

    @classmethod
    def from_response(cls, payload: dict) -> "Usage":
        usage = payload.get("usage") or {}
        return cls(
            prompt_tokens=usage.get("prompt_tokens", 0) or 0,
            completion_tokens=usage.get("completion_tokens", 0) or 0,
            total_tokens=usage.get("total_tokens", 0) or 0,
            # OpenRouter reports `cost` in USD when usage accounting is enabled.
            cost_usd=float(usage.get("cost", 0.0) or 0.0),
        )


@dataclass
class Completion:
    content: str
    usage: Usage
    generation_id: str | None
    raw: dict = field(repr=False, default_factory=dict)

    @property
    def finish_reason(self) -> str:
        """Why generation stopped. "length" means the output was truncated.

        Worth distinguishing from a parse failure: a cut-off response yields
        invalid JSON, and reporting that as "the model did not return valid
        JSON" points at the wrong problem entirely.
        """
        try:
            choice = self.raw["choices"][0]
        except (KeyError, IndexError, TypeError):
            return ""
        return choice.get("finish_reason") or choice.get("native_finish_reason") or ""

    def parsed(self) -> dict:
        try:
            return json.loads(self.content)
        except json.JSONDecodeError as exc:
            # A cut-off response is invalid JSON too, but the cause and the fix
            # are different — say which one this is.
            if self.finish_reason == "length":
                raise OpenRouterError(
                    f"Output truncated at the token limit (finish_reason=length): {exc}. "
                    f"Content was: {self.content[:400]!r}"
                ) from exc
            raise OpenRouterError(
                f"Model did not return valid JSON: {exc}. Content was: {self.content[:400]!r}"
            ) from exc


def _build_messages(images: list[Path], system_prompt: str, user_text: str,
                    audio: list[Path] | None = None) -> list[dict]:
    content: list[dict] = [{"type": "text", "text": user_text}]
    for path in images:
        content.append({"type": "image_url", "image_url": {"url": to_data_url(path)}})
    # Audio parts go after the images, and both go after the text. The text
    # part stays first so the instruction is read before the media it refers
    # to, matching how the image-only calls have always been built.
    for path in audio or []:
        content.append(to_input_audio_part(path))
    return [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": content},
    ]


def complete(
    cfg: Config,
    *,
    images: list[Path],
    system_prompt: str,
    user_text: str,
    response_format: dict,
    model: str | None = None,
    audio: list[Path] | None = None,
) -> Completion:
    """Send one chat completion request, retrying transient failures.

    `audio` is optional and defaults to None, so every existing call site —
    and every test stub written against the image-only signature — is
    unaffected. Only the transcription step passes it.
    """
    body = {
        "model": model or cfg.model,
        "messages": _build_messages(images, system_prompt, user_text, audio),
        "response_format": response_format,
        "temperature": cfg.temperature,
        # Ask OpenRouter to return real token counts and the charged cost.
        "usage": {"include": True},
    }
    headers = {
        "Authorization": f"Bearer {cfg.api_key}",
        "Content-Type": "application/json",
        "X-Title": "puppets-mvp",
    }

    logger.debug(
        "completion request: model=%s n_images=%d n_audio=%d",
        body["model"], len(images), len(audio or []),
    )
    last_error: Exception | None = None
    for attempt in range(cfg.max_retries):
        try:
            response = requests.post(
                OPENROUTER_URL, headers=headers, json=body, timeout=cfg.timeout
            )
            if response.status_code in RETRYABLE_STATUS:
                raise OpenRouterError(
                    f"HTTP {response.status_code}: {response.text[:300]}"
                )
            if response.status_code >= 400:
                raise OpenRouterError(
                    f"HTTP {response.status_code}: {response.text[:300]}"
                ) from None
            payload = response.json()
        except (requests.RequestException, OpenRouterError, ValueError) as exc:
            last_error = exc
            if attempt == cfg.max_retries - 1:
                break
            backoff = (2 ** attempt) + random.uniform(0, 0.5)
            logger.warning(
                "completion request failed (attempt %d/%d), retrying in %.1fs: %s",
                attempt + 1, cfg.max_retries, backoff, exc,
            )
            time.sleep(backoff)
            continue

        if "error" in payload and payload["error"]:
            raise OpenRouterError(str(payload["error"]))
        try:
            content = payload["choices"][0]["message"]["content"]
        except (KeyError, IndexError) as exc:
            raise OpenRouterError(f"Unexpected response shape: {payload}") from exc

        usage = Usage.from_response(payload)
        logger.info(
            "completion: model=%s tokens=%d+%d cost=$%.4f",
            body["model"], usage.prompt_tokens, usage.completion_tokens, usage.cost_usd,
        )
        return Completion(
            content=content,
            usage=usage,
            generation_id=payload.get("id"),
            raw=payload,
        )

    raise OpenRouterError(f"Request failed after {cfg.max_retries} attempts: {last_error}")


# --- Speech to text --------------------------------------------------------
#
# A separate endpoint, and a separate function, because a transcription model
# is not a chat model: it takes a multipart file upload rather than a JSON
# body, returns a transcript rather than a message, and supports no
# structured output. Trying to serve both through complete() would mean a
# function whose every line branched on which kind of model it had.


@dataclass
class Transcription:
    """The result of one speech-to-text call."""

    text: str
    language: str
    usage: Usage
    raw: dict = field(repr=False, default_factory=dict)


def transcribe(
    cfg: Config,
    *,
    audio: Path,
    model: str,
    language: str = "",
) -> Transcription:
    """Send one audio file to a speech-to-text model, retrying transient failures.

    `language` is an optional ISO-639-1 code that *forces* one language.
    Leaving it empty means auto-detect, but what that takes differs by model:
    openai/gpt-transcribe and qwen/qwen3-asr detect on their own when the
    field is absent, whereas deepgram/nova-3 treats an absent field as
    English-only and answers other-language audio with HTTP 200, a charge,
    and an empty transcript — it needs an explicit "multi" to detect.
    """
    # Validated before the first attempt rather than inside the loop — an
    # unsupported container will not become supported on a retry.
    content_type = f"audio/{audio_format(audio)}"
    form = {"model": model}
    detect = "multi" if "deepgram" in model else ""
    if language or detect:
        form["language"] = language or detect
    headers = {
        "Authorization": f"Bearer {cfg.api_key}",
        "X-Title": "puppets-mvp",
    }

    logger.debug("transcription request: model=%s file=%s", model, audio.name)
    last_error: Exception | None = None
    for attempt in range(cfg.max_retries):
        try:
            # Reopened per attempt: a retry has to send the file from the
            # start, and an already-consumed handle would upload zero bytes.
            with open(audio, "rb") as handle:
                response = requests.post(
                    TRANSCRIPTIONS_URL,
                    headers=headers,
                    files={"file": (audio.name, handle, content_type)},
                    data=form,
                    timeout=cfg.timeout,
                )
            if response.status_code in RETRYABLE_STATUS:
                raise OpenRouterError(
                    f"HTTP {response.status_code}: {response.text[:300]}"
                )
            if response.status_code >= 400:
                raise OpenRouterError(
                    f"HTTP {response.status_code}: {response.text[:300]}"
                ) from None
            payload = response.json()
        except (requests.RequestException, OpenRouterError, ValueError, OSError) as exc:
            last_error = exc
            if attempt == cfg.max_retries - 1:
                break
            backoff = (2 ** attempt) + random.uniform(0, 0.5)
            logger.warning(
                "transcription request failed (attempt %d/%d), retrying in %.1fs: %s",
                attempt + 1, cfg.max_retries, backoff, exc,
            )
            time.sleep(backoff)
            continue

        if isinstance(payload, dict) and payload.get("error"):
            raise OpenRouterError(str(payload["error"]))

        text = payload.get("text")
        if text is None and isinstance(payload.get("segments"), list):
            # Some providers return timed segments instead of a flat string.
            text = " ".join(
                seg.get("text", "") for seg in payload["segments"]
                if isinstance(seg, dict)
            )
        if text is None:
            raise OpenRouterError(
                f"No transcript in the response. Keys were: {sorted(payload)}"
            )

        usage = Usage.from_response(payload)
        logger.info(
            "transcription: model=%s tokens=%d+%d cost=$%.4f",
            model, usage.prompt_tokens, usage.completion_tokens, usage.cost_usd,
        )
        return Transcription(
            text=text.strip(),
            language=payload.get("language") or "",
            usage=usage,
            raw=payload,
        )

    raise OpenRouterError(
        f"Transcription failed after {cfg.max_retries} attempts: {last_error}"
    )
