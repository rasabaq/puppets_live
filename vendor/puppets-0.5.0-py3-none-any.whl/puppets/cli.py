"""Command line entry point.

    python -m puppets.cli screenshots/ --model google/gemini-2.5-flash
"""

from __future__ import annotations

import argparse
from dataclasses import replace

from .config import DEFAULT_MODE, Config
from .images import collect_groups
from .logging_setup import setup_logging
from .pipeline import run
from .storage import write_run


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="puppets",
        description="Label screenshots for ads, food, and ultra-processed food.",
    )
    parser.add_argument(
        "paths", nargs="+",
        help="Image files and/or directories. Each directory is one video "
             "and each loose file is a one-frame video.",
    )
    parser.add_argument("--model", help="OpenRouter model id (default: $PUPPETS_MODEL).")
    parser.add_argument(
        "--max-workers", type=int, default=4,
        help="Parallel API requests (default: 4).",
    )
    parser.add_argument(
        "--rationale", action="store_true",
        help=(
            "Ask the model for a one-sentence reason per label. Adds a field "
            "to the response schema and roughly a fifth to the run cost; the "
            "reasons land in labels.csv and raw.jsonl."
        ),
    )
    parser.add_argument(
        "--audio-escalation", action="store_true",
        help=(
            "When the frames and metadata show no ad, transcribe the video's "
            "audio and judge whether the speech discloses a paid promotion. "
            "Only for bundles that carry audio. Can "
            "raise is_ad from 0 to 1, never lower it."
        ),
    )
    parser.add_argument(
        "--stt-language", default=None,
        help="Force one language for the audio, as an ISO-639-1 code, e.g. es. The default is to let the speech-to-text model detect the language itself; pin one only when auto-detect gets a short or noisy clip wrong.",
    )
    parser.add_argument(
        "--dry-run", action="store_true",
        help="List the bundles that would be sent and exit without calling the API.",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    setup_logging()
    args = build_parser().parse_args(argv)
    groups = collect_groups(args.paths)
    images = [image for group in groups for image in group]
    # Labelling works on a whole video at a time, so the bundles are the
    # videos themselves — one video is one bundle, always.
    bundles = groups
    unit = "video"
    units = "video(s)"

    if args.dry_run:
        print(f"{len(images)} image(s) in {len(bundles)} {units}, mode={DEFAULT_MODE}")
        for position, bundle in enumerate(bundles, start=1):
            names = ", ".join(p.name for p in bundle)
            print(f"  {unit} {position}: {names}")
        return 0

    cfg = Config.from_env(model=args.model,
                          max_workers=args.max_workers, rationale=args.rationale,
                          audio_escalation=args.audio_escalation)
    if args.stt_language is not None:
        cfg = replace(cfg, stt_language=args.stt_language)
    print(f"Labelling {len(images)} image(s) in {len(bundles)} {units} "
          f"with {cfg.model} (mode={cfg.mode})...")

    results, summary = run(cfg, bundles)
    out_dir = write_run(results, summary)

    for result in results:
        names = ", ".join(p.rsplit("/", 1)[-1] for p in result.image_paths)
        if len(names) > 80:
            names = names[:77] + "..."
        if result.error:
            print(f"  {names}: ERROR {result.error[:120]}")
        else:
            print(f"  {names}: ad={result.is_ad} food={result.has_food} "
                  f"upf={result.is_upf}  ${result.cost_usd:.6f}")
            if cfg.rationale:
                for field_name in ("is_ad", "has_food", "is_upf"):
                    reason = getattr(result, f"{field_name}_reason")
                    if reason:
                        print(f"      {field_name}: {reason}")

    print(f"\nAPI calls:      {summary.n_api_calls}")
    print(f"Errors:         {summary.n_errors}/{summary.n_label_sets}")
    print(f"Tokens:         {summary.total_prompt_tokens} in / "
          f"{summary.total_completion_tokens} out")
    print(f"Total cost:     ${summary.total_cost_usd:.6f}")
    print(f"Cost per image: ${summary.mean_cost_per_image_usd:.6f}")
    print(f"Written to:     {out_dir}")
    return 1 if summary.n_errors == summary.n_label_sets and summary.n_label_sets else 0


if __name__ == "__main__":
    raise SystemExit(main())
