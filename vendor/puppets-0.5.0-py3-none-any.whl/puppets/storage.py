"""Run output: raw JSONL log of record, plus a flat CSV of labels.

The JSONL keeps the complete API response for every call, so a SQLite layer
(and the human-annotated benchmark comparison) can be rebuilt from it later
without re-running anything.
"""

from __future__ import annotations

import csv
import io
import json
import logging
from dataclasses import asdict
from pathlib import Path

from .config import REPO_ROOT
from .pipeline import LabelResult, RunSummary

logger = logging.getLogger(__name__)

CSV_COLUMNS = [
    "bundle_id",
    "n_images",
    "image_paths",
    "is_ad",
    "has_food",
    "is_upf",
    # Empty on a default run; filled when the run had rationale enabled.
    "is_ad_reason",
    "has_food_reason",
    "is_upf_reason",
    "prompt_tokens",
    "completion_tokens",
    "cost_usd",
    "generation_id",
    "error",
    # Empty unless the run had audio escalation on and the audio channel
    # failed or had nothing to judge. Kept out of `error` on purpose — see
    # LabelResult.audio_error.
    "audio_error",
]


def labels_csv(results: list[LabelResult]) -> str:
    """The flat analysis table as a string (also used for browser downloads)."""
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=CSV_COLUMNS, lineterminator="\n")
    writer.writeheader()
    for result in results:
        row = result.as_row()
        row["n_images"] = result.n_images
        row["image_paths"] = "|".join(result.image_paths)
        writer.writerow({k: v for k, v in row.items() if k in CSV_COLUMNS})
    return buffer.getvalue()


def raw_jsonl(results: list[LabelResult]) -> str:
    """One JSON record per label set (one bundle of N images is one line), \
including the full API response."""
    return "".join(
        json.dumps(asdict(result), ensure_ascii=False) + "\n" for result in results
    )


def summary_json(summary: RunSummary) -> str:
    return json.dumps(asdict(summary), indent=2) + "\n"


def write_run(results: list[LabelResult], summary: RunSummary,
              runs_dir: Path | None = None) -> Path:
    out_dir = (runs_dir or REPO_ROOT / "runs") / summary.run_id
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "raw.jsonl").write_text(raw_jsonl(results), encoding="utf-8")
    (out_dir / "labels.csv").write_text(labels_csv(results), encoding="utf-8")
    (out_dir / "summary.json").write_text(summary_json(summary), encoding="utf-8")
    logger.info("wrote run %s to %s (%d result(s))", summary.run_id, out_dir, len(results))
    return out_dir
