"""A record of *how* a unit got labelled, not just what it got labelled.

A LabelResult answers "what did the run decide". This module answers the
question a benchmark actually raises when a number moves: "which agent
decided it, on what evidence, and which branch did this unit take". The
pipeline's structure — ad_agent and food_agent in parallel, upf_agent gated
on has_food, the audio channel gated on is_ad — is real control flow that
vanishes the moment the result dataclass is filled in. A trace keeps it.

The model is deliberately small and flow-agnostic, so the frame pipeline and
the whole-video pipeline can both emit into it and the same renderer draws
both:

* a ``Step`` is one thing that happened — an agent call, a gate, a tool run;
* ``inputs`` names the steps it followed, and ``condition`` labels that edge,
  which together make the steps a DAG without anyone declaring a graph;
* a ``UnitTrace`` is every step for one unit, plus the gold labels where they
  are known, so a renderer can colour a node by agreement without a join.

Traces are data, not display: nothing here knows about graphviz or Streamlit.
See ``trace_graph.py`` for the drawing.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

# What a step is. Kept as plain strings rather than an enum so a trace read
# back from a newer file does not explode on a kind this version never heard of.
AGENT = "agent"      # a model call that produced (or failed to produce) a value
GATE = "gate"        # a branch the code took, with no call of its own
TOOL = "tool"        # a non-labelling step: a download, a transcription

OK = "ok"
ERROR = "error"
SKIPPED = "skipped"  # the step exists in the flow but this unit did not reach it

TRACES_DIRNAME = "traces"


@dataclass
class Step:
    """One thing that happened while labelling a unit."""

    id: str
    kind: str = AGENT
    label: str = ""
    # The codebook variable this step decided, when it decided one.
    variable: str | None = None
    value: object = None
    reason: str | None = None
    status: str = OK
    error: str | None = None

    model: str = ""
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    duration_seconds: float = 0.0

    # The steps this one followed, and the label for those edges. An empty
    # `inputs` means the step ran at the start of the unit.
    inputs: list[str] = field(default_factory=list)
    condition: str = ""

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class UnitTrace:
    """Every step for one unit, plus what the reference set says about it."""

    unit_id: str
    # Human-readable: a URL for a video, a joined filename list for frames.
    unit_label: str = ""
    mode: str = ""
    model: str = ""
    steps: list[Step] = field(default_factory=list)
    # Final labels as the unit ended up recorded, so the trace is readable
    # without re-deriving them from the steps.
    labels: dict = field(default_factory=dict)
    # Gold labels where known — filled in by the benchmark, absent on a plain
    # production run, which has nothing to compare against.
    gold: dict = field(default_factory=dict)
    error: str | None = None

    def add(self, step: Step) -> Step:
        self.steps.append(step)
        return step

    def step(self, step_id: str) -> Step | None:
        for step in self.steps:
            if step.id == step_id:
                return step
        return None

    @property
    def cost_usd(self) -> float:
        return sum(s.cost_usd for s in self.steps)

    def agrees(self, variable: str) -> bool | None:
        """True/False against gold, or None when there is nothing to compare.

        None covers both "no gold for this unit" and "gold says the variable
        is not applicable here" — is_upf where the codebook does not call for
        it — which must not be drawn as a disagreement.
        """
        if variable not in self.gold or self.gold.get(variable) is None:
            return None
        if self.labels.get(variable) is None:
            return False
        return self.labels[variable] == self.gold[variable]

    def step_agrees(self, step: "Step") -> bool | None:
        """Agreement for one step's own value, not the unit's final label.

        These differ exactly where a later step overrode an earlier one — the
        audio channel flipping is_ad. Colouring ad_agent by the final label
        there would paint it right when it was wrong, which is the one thing
        the graph exists to make visible.
        """
        if not step.variable or step.status != OK:
            return None
        gold = self.gold.get(step.variable)
        if step.variable not in self.gold or gold is None:
            return None
        return step.value == gold

    def as_dict(self) -> dict:
        data = asdict(self)
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "UnitTrace":
        known_step = set(Step.__dataclass_fields__)
        steps = [
            Step(**{k: v for k, v in raw.items() if k in known_step})
            for raw in data.get("steps", [])
        ]
        known = set(cls.__dataclass_fields__)
        kwargs = {k: v for k, v in data.items() if k in known and k != "steps"}
        return cls(steps=steps, **kwargs)


# --- Storage ---------------------------------------------------------------
#
# One JSONL file per benchmark, beside the records rather than inside them.
# Inside would work and would be one less file, but a record is a small,
# human-diffable artefact that travels in git; traces are an order of
# magnitude bigger and grow with the gold set. Keeping them separate means a
# record stays readable and a trace file can be deleted without losing the
# numbers it explains.


def traces_dir(benchmarks_directory: Path) -> Path:
    return Path(benchmarks_directory) / TRACES_DIRNAME


def traces_path(benchmark_id: str, benchmarks_directory: Path) -> Path:
    return traces_dir(benchmarks_directory) / f"{benchmark_id}.jsonl"


def save_traces(benchmark_id: str, traces: "list[UnitTrace]",
                benchmarks_directory: Path) -> Path | None:
    """Write one trace per line. Returns None when there is nothing to write."""
    if not traces:
        return None
    path = traces_path(benchmark_id, benchmarks_directory)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for trace in traces:
            handle.write(json.dumps(trace.as_dict(), ensure_ascii=False) + "\n")
    return path


def load_traces(benchmark_id: str,
                benchmarks_directory: Path) -> "list[UnitTrace]":
    """Read a benchmark's traces, or [] when that run predates tracing.

    A missing file is the normal case for every record written before this
    module existed, so it is not an error — the caller renders "no trace" and
    the rest of the benchmark view keeps working.
    """
    path = traces_path(benchmark_id, benchmarks_directory)
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []
    traces = []
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            traces.append(UnitTrace.from_dict(json.loads(line)))
        except (ValueError, TypeError):
            # One unreadable line must not cost the whole file.
            continue
    return traces


def delete_traces(benchmark_id: str, benchmarks_directory: Path) -> bool:
    path = traces_path(benchmark_id, benchmarks_directory)
    try:
        path.unlink()
        return True
    except OSError:
        return False


__all__ = [
    "AGENT", "ERROR", "GATE", "OK", "SKIPPED", "TOOL", "Step", "UnitTrace",
    "delete_traces", "load_traces", "save_traces", "traces_dir", "traces_path",
]
