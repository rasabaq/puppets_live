"""Runtime configuration, loaded from environment / .env."""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

def _looks_like_checkout(path: Path) -> bool:
    """True if `path` looks like the puppets checkout, not just any directory."""
    return (path / "tests" / "fixtures" / "gold").is_dir() or (path / ".git").exists()


def _resolve_repo_root() -> Path:
    """Where the checkout lives, honouring an override, else best-effort.

    Once installed as a wheel, ``parents[2]`` from this file lands in
    site-packages, not a checkout. Prefer $PUPPETS_REPO_ROOT; else use
    ``parents[2]`` only if it actually looks like the checkout (running from
    source); else fall back to the current working directory.
    """
    override = os.environ.get("PUPPETS_REPO_ROOT", "").strip()
    if override:
        return Path(override)
    candidate = Path(__file__).resolve().parents[2]
    if _looks_like_checkout(candidate):
        return candidate
    return Path.cwd()


REPO_ROOT = _resolve_repo_root()
DEFAULT_MODEL = "google/gemini-2.5-flash"
# Speech-to-text for the audio escalation. Not derived from DEFAULT_MODEL:
# transcription is a different modality served by a different endpoint, and
# the general multimodal models tested against this one transcribed audibly
# worse — one looped a single clause until it ran out of output budget.
DEFAULT_STT_MODEL = "openai/gpt-transcribe"

# The one labelling flow: a focused ad/food/upf agent per field over a whole
# unit. The single-pass "per_bundle" mode that used to sit beside it is gone,
# but the name is still written into every run and benchmark record so old
# records stay readable and comparisons stay mode-aware.
DEFAULT_MODE = "agent_per_bundle"
OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
# Dedicated speech-to-text models (openai/gpt-transcribe, deepgram/nova-3,
# qwen/qwen3-asr-*) are audio->transcription, not chat models. They do not
# answer on /chat/completions at all — they need this endpoint, which takes a
# multipart upload rather than a JSON body with a base64 part.
TRANSCRIPTIONS_URL = "https://openrouter.ai/api/v1/audio/transcriptions"


def load_dotenv(path: Path | None = None) -> None:
    """Minimal .env loader. Existing environment variables win."""
    path = path or REPO_ROOT / ".env"
    if not path.exists():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        os.environ.setdefault(key.strip(), value.strip().strip("'\""))


def _env_flag(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


@dataclass(frozen=True)
class Config:
    api_key: str
    model: str
    # The labelling flow. "agent_per_bundle" — one focused agent per field
    # over a unit — is the only one left; the single-pass "per_bundle" mode
    # it replaced is gone. Kept as a field because every run record and
    # benchmark on disk carries it, and older records name modes that no
    # longer run. A unit is a bundle of one or more images: per-image
    # labelling is a bundle size of 1, not a mode of its own.
    mode: str
    temperature: float
    max_workers: int
    timeout: int
    max_retries: int
    ad_model: str = ""
    food_model: str = ""
    upf_model: str = ""
    # Ask the model to justify each label (see schema.REASON_INSTRUCTION).
    # Off by default: it changes the response schema and the prompt, so a
    # rationale run is a different labelling contract, not the same run with
    # extra logging — benchmarks.prompt_fingerprint reflects that.
    rationale: bool = False
    # Escalate to the audio channel when the visual/metadata pass does not
    # find an ad. Off by default and fingerprinted, for the same reason as
    # `rationale`: it adds two prompts and can change a label, so an
    # escalated run is a different labelling contract rather than the same
    # run with more logging.
    audio_escalation: bool = False
    stt_model: str = DEFAULT_STT_MODEL
    audio_ad_model: str = ""
    # ISO-639-1 code forced on the speech-to-text model. Empty, the normal
    # case, means "let the model detect it" — transcribe() supplies whatever
    # each model needs to auto-detect. Set this only to pin one language,
    # which is marginally more accurate on short or noisy clips.
    stt_language: str = ""

    @classmethod
    def from_env(cls, *, model: str | None = None, mode: str = DEFAULT_MODE,
                 max_workers: int = 4, rationale: bool | None = None,
                 audio_escalation: bool | None = None) -> "Config":
        load_dotenv()
        api_key = os.environ.get("OPENROUTER_API_KEY", "").strip()
        if not api_key:
            raise SystemExit(
                "OPENROUTER_API_KEY is not set. Copy .env.example to .env and fill it in."
            )
        resolved_model = model or os.environ.get("PUPPETS_MODEL") or DEFAULT_MODEL
        return cls(
            api_key=api_key,
            model=resolved_model,
            mode=mode,
            temperature=float(os.environ.get("PUPPETS_TEMPERATURE", "0")),
            max_workers=max_workers,
            timeout=int(os.environ.get("PUPPETS_TIMEOUT", "120")),
            max_retries=int(os.environ.get("PUPPETS_MAX_RETRIES", "3")),
            ad_model=os.environ.get("PUPPETS_AD_MODEL") or resolved_model,
            food_model=os.environ.get("PUPPETS_FOOD_MODEL") or resolved_model,
            upf_model=os.environ.get("PUPPETS_UPF_MODEL") or resolved_model,
            rationale=(
                _env_flag("PUPPETS_RATIONALE") if rationale is None else rationale
            ),
            audio_escalation=(
                _env_flag("PUPPETS_AUDIO_ESCALATION")
                if audio_escalation is None else audio_escalation
            ),
            stt_model=os.environ.get("PUPPETS_STT_MODEL") or DEFAULT_STT_MODEL,
            stt_language=os.environ.get("PUPPETS_STT_LANGUAGE", "").strip(),
            audio_ad_model=os.environ.get("PUPPETS_AUDIO_AD_MODEL") or resolved_model,
        )

    def model_for_agent(self, agent_name: str) -> str:
        """Resolved model id for a given agent or step, defaulting to `model`.

        "transcribe" is the exception that does not default to `model`: a
        chat model cannot serve the transcription endpoint at all, so falling
        back to one would guarantee a failure rather than a degraded result.
        Config.stt_model always holds a real speech-to-text id.
        """
        return {
            "ad_agent": self.ad_model,
            "food_agent": self.food_model,
            "upf_agent": self.upf_model,
            # Never falls through to `model` below: a chat model cannot
            # serve /audio/transcriptions at all, so the fallback would
            # guarantee a failure instead of a degraded result.
            "transcribe": self.stt_model or DEFAULT_STT_MODEL,
            "audio_ad_agent": self.audio_ad_model,
        }.get(agent_name) or self.model
