"""Versioned benchmark records: run the gold set, score it, keep it on disk.

``gold.py`` answers "how well did this one run agree with the reference set?".
This module answers the question that only makes sense over time: "is v0.2
better than v0.1, and what did it cost?". It does three things and nothing
else:

* runs the real pipeline over the gold set (``execute``),
* turns a GoldReport into a stamped, versioned record (``record_from_report``),
* stores and reloads those records locally (``save`` / ``load_all``).

Records are plain JSON under ``benchmarks/`` — one file per run, no database.
That directory is deliberately *not* gitignored, unlike ``runs/``: a benchmark
history is only useful if it travels with the code version it measures.

A record pins the things that can move the numbers — model, mode, the prompt
text, the gold labels, the git commit — so a comparison that is not
apples-to-apples can be spotted instead of silently believed.
"""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import time
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from . import agents
from .config import REPO_ROOT, Config
from .gold import GOLD_CSV, GoldReport, GoldRow, evaluable, score_predictions
from .pipeline import Bundle, run
from .trace import UnitTrace, delete_traces, save_traces
from .schema import (
    LABEL_FIELDS,
    REASON_INSTRUCTION,
    SYSTEM_PROMPT,
)

BENCHMARKS_DIR = REPO_ROOT / "benchmarks"
RECORD_SUFFIX = ".json"


class BenchmarkError(Exception):
    """The benchmark cannot be run as asked — a setup problem, not a bad score."""


# --- Where records live ----------------------------------------------------


def benchmarks_dir(directory: Path | None = None) -> Path:
    """Explicit argument wins, then $PUPPETS_BENCHMARKS_DIR, then benchmarks/."""
    if directory is not None:
        return Path(directory)
    override = os.environ.get("PUPPETS_BENCHMARKS_DIR", "").strip()
    return Path(override) if override else BENCHMARKS_DIR


# --- Provenance ------------------------------------------------------------


def _git(*args: str) -> str:
    """Best-effort git query. Returns "" outside a repo or without git."""
    try:
        out = subprocess.run(
            ["git", "-C", str(REPO_ROOT), *args],
            capture_output=True, text=True, timeout=5, check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return ""
    return out.stdout.strip() if out.returncode == 0 else ""


@dataclass(frozen=True)
class GitState:
    commit: str = ""
    branch: str = ""
    dirty: bool = False
    describe: str = ""


def git_state() -> GitState:
    return GitState(
        commit=_git("rev-parse", "--short", "HEAD"),
        branch=_git("rev-parse", "--abbrev-ref", "HEAD"),
        # Uncommitted changes mean the commit id does not identify what ran.
        dirty=bool(_git("status", "--porcelain")),
        describe=_git("describe", "--tags", "--always", "--dirty"),
    )


def suggest_version(state: GitState | None = None) -> str:
    """A sensible default for the version box: the tag if there is one."""
    state = state or git_state()
    return state.describe or state.commit or "unversioned"


def fingerprint(*parts: str) -> str:
    """Hash an ordered set of prompt texts into a short, stable id.

    Public because the whole-video flow fingerprints its own agent prompts the
    same way (video_testing.benchmark.prompt_fingerprint) and the two must be
    computed identically or a video record and a frame record could collide.
    """
    digest = hashlib.sha256()
    for part in parts:
        digest.update(part.encode("utf-8"))
        digest.update(b"\x00")
    return digest.hexdigest()[:12]


def prompt_fingerprint(*, rationale: bool = False,
                       audio_escalation: bool = False,
                       stt_model: str = "") -> str:
    """Identifies the labelling contract. Changes whenever a prompt is edited.

    Hashes the shared prompt corpus (schema.SYSTEM_PROMPT) plus every
    agents.py prompt, in a fixed order, so editing an agent's prompt is
    reflected in the fingerprint and like-for-like comparisons against a
    differently-prompted agent run get flagged. This includes each
    spec's metadata-aware prompt (falling back to "" for specs that don't
    have one): _AD_SYSTEM_META is part of the labelling
    contract for every unit that carries metadata, so editing its
    disclosure wording must move the fingerprint too.

    Note that collapsing the single/bundle prompt pairs into one prompt each
    moved every fingerprint this function produces. Records committed under
    benchmarks/ before that change carry the old values and are flagged as
    not comparable, which is correct: their prompts no longer exist.

    `rationale` participates for the same reason. Asking for a justification
    appends REASON_INSTRUCTION to every prompt and adds a field to every
    response schema, so a rationale run is measuring a different labelling
    contract; folding the flag in here is what stops a rationale run and a
    plain one from being compared as if the only difference were the code.
    It is mixed in as a trailing marker rather than by hashing the composed
    with_reason() prompts, so a rationale-on and a rationale-off fingerprint
    differ by exactly this one marker.

    `audio_escalation` participates for the same reason again, and is
    appended last so that with it off the fingerprint is just the prompt set
    above and nothing more. With it on,
    the two audio prompts are hashed in, because a run that can flip is_ad
    from 0 to 1 on the strength of a transcript is measuring a different
    labelling contract from one that cannot.

    `stt_model` is hashed in alongside them, and it is the one entry here
    that is a model id rather than a prompt. It belongs because transcription
    has no prompt to fingerprint: what the audio channel sees is decided
    entirely by which recogniser produced the transcript, and two recognisers
    that disagree on a discount code produce different labels from identical
    prompts. Leaving it out would let a Whisper run and a gpt-transcribe run
    compare as like-for-like.
    """
    parts = (
        SYSTEM_PROMPT,
        *(
            part
            for spec in agents.AGENTS
            for part in (spec.system_prompt, spec.system_prompt_meta or "")
        ),
    )
    if rationale:
        parts = (*parts, REASON_INSTRUCTION)
    if audio_escalation:
        parts = (*parts, *(spec.system_prompt for spec in agents.AUDIO_AGENTS),
                 stt_model)
    return fingerprint(*parts)


def gold_fingerprint(path: Path | None = None) -> str:
    """Identifies the reference set. Changes whenever a gold label is edited."""
    path = path or GOLD_CSV
    try:
        return fingerprint(path.read_text(encoding="utf-8"))
    except OSError:
        return ""


# --- Scoring: turning agreement into points --------------------------------


def points(report: GoldReport) -> tuple[int, int]:
    """Points scored and points available, over every variable compared.

    One point per variable-level comparison the model got right. is_upf is only
    compared where the gold coding says food is present (see
    gold.score_predictions), so the denominator is *not* 3 x units — it is
    however many comparisons the codebook actually calls for. Units that
    errored score no points and are not in the denominator either; a failed API
    call is not evidence about the codebook.
    """
    scored = sum(s.n_agree for s in report.scores.values())
    available = sum(s.n for s in report.scores.values())
    return scored, available


# --- The record ------------------------------------------------------------


@dataclass
class BenchmarkRecord:
    """One benchmark run, stamped with everything needed to compare it later."""

    benchmark_id: str
    version: str
    notes: str
    created_at: str

    model: str
    mode: str

    # Provenance — what code and what reference set produced these numbers.
    git_commit: str = ""
    git_branch: str = ""
    git_dirty: bool = False
    prompt_fingerprint: str = ""
    gold_fingerprint: str = ""
    # Whether the model was asked to justify each label. Part of the
    # labelling contract, and already folded into prompt_fingerprint; stored
    # separately so it is readable without recomputing a hash.
    rationale: bool = False
    # Whether the run escalated to the audio channel. Same treatment as
    # rationale: folded into prompt_fingerprint, and stored plainly so it is
    # readable without recomputing a hash.
    audio_escalation: bool = False
    # Which speech-to-text model produced the transcripts. Folded into
    # prompt_fingerprint; stored plainly so it is readable without
    # recomputing a hash, and so a record says what it actually ran.
    stt_model: str = ""

    # What the audio channel actually did, as opposed to whether it was
    # switched on. `audio_escalation: true` above only says the trigger was
    # armed; these four say whether it fired, worked, and changed anything:
    #
    #   n_escalations   units where the visual pass found no ad and the audio
    #                   channel ran. 0 with audio_escalation on means every
    #                   unit was already is_ad = 1, or no row named audio.
    #   n_audio_flips   units the audio channel promoted to is_ad = 1. This
    #                   is the one that matters: 0 flips means this record is
    #                   numerically an audio-off run that cost more.
    #   n_audio_errors  escalations that yielded nothing (unreadable file,
    #                   failed transcription, no speech). Not label errors —
    #                   see GoldReport.n_audio_errors.
    #   audio_cost_usd  the escalation's share of total_cost_usd, already
    #                   included there.
    #
    # None, not 0, is the default: records written before these fields
    # existed have no counters, and defaulting them to 0 would make an old
    # audio run claim the channel never fired. None means "not recorded";
    # every run from here on writes real numbers.
    n_escalations: int | None = None
    n_audio_flips: int | None = None
    n_audio_errors: int | None = None
    audio_cost_usd: float | None = None

    # Coverage.
    n_units: int = 0
    n_evaluated: int = 0
    n_skipped_unlabelled: int = 0
    n_skipped_disputed: int = 0
    n_errors: int = 0
    # Evaluable gold rows the whole-video flow could not reach because the row
    # names no source URL. None on every frame record — frames are on disk, so
    # the question does not arise — and a real number on a video record, where
    # it is the difference between "scored the gold set" and "scored the part
    # of the gold set that still has a link".
    n_skipped_no_url: int | None = None

    # Cost.
    total_cost_usd: float = 0.0
    cost_per_unit_usd: float = 0.0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0
    duration_seconds: float = 0.0

    # Points.
    points: int = 0
    points_possible: int = 0

    scores: dict[str, dict] = field(default_factory=dict)
    disagreements: list[dict] = field(default_factory=list)
    errors: list[dict] = field(default_factory=list)

    @property
    def score_pct(self) -> float:
        return self.points / self.points_possible if self.points_possible else 0.0

    @property
    def mean_kappa(self) -> float:
        """Kappa averaged over the variables that had anything to compare."""
        values = [s["kappa"] for s in self.scores.values() if s.get("n")]
        return sum(values) / len(values) if values else 0.0

    @property
    def images_per_hour(self) -> float:
        """Throughput: units scored per hour of wall-clock run time.

        Uses n_evaluated (not n_units) since that is what actually got a model
        call — skipped rows cost no time. Zero when duration wasn't recorded
        (older records) so callers can render a blank instead of a bogus rate.
        """
        if not self.duration_seconds:
            return 0.0
        return self.n_evaluated / (self.duration_seconds / 3600)

    @property
    def comparable_key(self) -> tuple[str, str, str, str]:
        """Two records with the same key were measured the same way.

        A difference here means a delta is not attributable to the code change
        alone — the model, the mode, the prompt or the gold labels also moved.
        """
        return (self.model, self.mode, self.prompt_fingerprint, self.gold_fingerprint)

    def as_dict(self) -> dict:
        data = asdict(self)
        # Derived values are written out too, so the JSON is readable on its own.
        data["score_pct"] = self.score_pct
        data["mean_kappa"] = self.mean_kappa
        data["images_per_hour"] = self.images_per_hour
        return data

    @classmethod
    def from_dict(cls, data: dict) -> "BenchmarkRecord":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in data.items() if k in known})


def record_from_report(
    report: GoldReport,
    *,
    version: str,
    notes: str = "",
    n_units: int = 0,
    total_prompt_tokens: int = 0,
    total_completion_tokens: int = 0,
    duration_seconds: float = 0.0,
    n_escalations: int = 0,
    audio_cost_usd: float = 0.0,
    gold_path: Path | None = None,
    state: GitState | None = None,
    fingerprint_override: str | None = None,
    n_skipped_no_url: int | None = None,
) -> BenchmarkRecord:
    state = state or git_state()
    scored, available = points(report)
    return BenchmarkRecord(
        benchmark_id=f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:6]}",
        version=version.strip() or suggest_version(state),
        notes=notes.strip(),
        created_at=datetime.now(timezone.utc).isoformat(),
        model=report.model,
        mode=report.mode,
        git_commit=state.commit,
        git_branch=state.branch,
        git_dirty=state.dirty,
        # An explicit value is how a sibling flow with its own prompts (the
        # whole-video benchmark) stamps its own contract instead of the frame
        # agents' — a record must fingerprint the prompts that actually ran.
        prompt_fingerprint=fingerprint_override if fingerprint_override
        else prompt_fingerprint(
            rationale=report.rationale,
            audio_escalation=report.audio_escalation,
            stt_model=report.stt_model),
        rationale=report.rationale,
        audio_escalation=report.audio_escalation,
        stt_model=report.stt_model,
        n_escalations=n_escalations,
        n_audio_flips=report.n_audio_flips,
        n_audio_errors=report.n_audio_errors,
        audio_cost_usd=audio_cost_usd,
        gold_fingerprint=gold_fingerprint(gold_path),
        n_units=n_units or report.n_rows,
        n_evaluated=report.n_evaluated,
        n_skipped_unlabelled=report.n_skipped_unlabelled,
        n_skipped_disputed=report.n_skipped_disputed,
        n_errors=report.n_errors,
        n_skipped_no_url=n_skipped_no_url,
        total_cost_usd=report.total_cost_usd,
        cost_per_unit_usd=(
            report.total_cost_usd / report.n_evaluated if report.n_evaluated else 0.0
        ),
        total_prompt_tokens=total_prompt_tokens,
        total_completion_tokens=total_completion_tokens,
        duration_seconds=duration_seconds,
        points=scored,
        points_possible=available,
        scores={
            name: {"n": s.n, "n_agree": s.n_agree, "accuracy": s.accuracy,
                   "kappa": s.kappa}
            for name, s in report.scores.items()
        },
        disagreements=[
            {"image": d.image, "variable": d.variable, "gold": d.gold,
             "predicted": d.predicted, "rationale": d.rationale,
             "model_rationale": d.model_rationale}
            for d in report.disagreements
        ],
        errors=[
            {"image": e.image, "error": e.error} for e in report.errors
        ],
    )


# --- Local store -----------------------------------------------------------


def _slug(text: str) -> str:
    """Filename-safe fragment; keeps the version readable in `ls`."""
    kept = [c if c.isalnum() or c in "-._" else "-" for c in text]
    return "".join(kept).strip("-")[:40] or "run"


def save(record: BenchmarkRecord, directory: Path | None = None) -> Path:
    directory = benchmarks_dir(directory)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / f"{record.benchmark_id}-{_slug(record.version)}{RECORD_SUFFIX}"
    path.write_text(json.dumps(record.as_dict(), indent=2) + "\n", encoding="utf-8")
    return path


def load_all(directory: Path | None = None) -> list[BenchmarkRecord]:
    """Every stored record, newest first. Unreadable files are skipped, not fatal."""
    directory = benchmarks_dir(directory)
    if not directory.is_dir():
        return []
    records = []
    for path in sorted(directory.glob(f"*{RECORD_SUFFIX}")):
        try:
            records.append(BenchmarkRecord.from_dict(
                json.loads(path.read_text(encoding="utf-8"))
            ))
        except (OSError, ValueError, TypeError):
            continue
    records.sort(key=lambda r: r.created_at, reverse=True)
    return records


def find(benchmark_id: str, directory: Path | None = None) -> BenchmarkRecord | None:
    return next(
        (r for r in load_all(directory) if r.benchmark_id == benchmark_id), None
    )


def delete(benchmark_id: str, directory: Path | None = None) -> bool:
    directory = benchmarks_dir(directory)
    for path in directory.glob(f"{benchmark_id}-*{RECORD_SUFFIX}"):
        path.unlink()
        # The trace explains a record that no longer exists, so it goes with
        # it. Best-effort: a run from before tracing has no trace file, and
        # that is not a failed delete.
        delete_traces(benchmark_id, directory)
        return True
    return False


# --- Comparison ------------------------------------------------------------


@dataclass
class Comparison:
    """Baseline vs candidate. Deltas are candidate minus baseline."""

    baseline: BenchmarkRecord
    candidate: BenchmarkRecord

    @property
    def d_score_pct(self) -> float:
        return self.candidate.score_pct - self.baseline.score_pct

    @property
    def d_points(self) -> int:
        return self.candidate.points - self.baseline.points

    @property
    def d_cost(self) -> float:
        return self.candidate.total_cost_usd - self.baseline.total_cost_usd

    @property
    def d_errors(self) -> int:
        return self.candidate.n_errors - self.baseline.n_errors

    def d_accuracy(self, variable: str) -> float | None:
        """None when a variable was not compared in both runs — a blank cell is
        honest, a 0.0 delta would not be."""
        a = self.baseline.scores.get(variable)
        b = self.candidate.scores.get(variable)
        if not a or not b or not a.get("n") or not b.get("n"):
            return None
        return b["accuracy"] - a["accuracy"]

    def d_kappa(self, variable: str) -> float | None:
        a = self.baseline.scores.get(variable)
        b = self.candidate.scores.get(variable)
        if not a or not b or not a.get("n") or not b.get("n"):
            return None
        return b["kappa"] - a["kappa"]

    @property
    def caveats(self) -> list[str]:
        """Reasons this comparison is not measuring the code change alone."""
        notes = []
        if self.baseline.model != self.candidate.model:
            notes.append(
                f"different model ({self.baseline.model} → {self.candidate.model})"
            )
        if self.baseline.mode != self.candidate.mode:
            notes.append(f"different mode ({self.baseline.mode} → {self.candidate.mode})")
        if self.baseline.prompt_fingerprint != self.candidate.prompt_fingerprint:
            notes.append("the prompt changed between these runs")
        if self.baseline.gold_fingerprint != self.candidate.gold_fingerprint:
            notes.append("gold.csv changed between these runs — the target moved")
        if self.baseline.points_possible != self.candidate.points_possible:
            notes.append(
                f"different number of comparisons "
                f"({self.baseline.points_possible} → {self.candidate.points_possible})"
            )
        if self.baseline.git_dirty or self.candidate.git_dirty:
            notes.append("at least one run was made with uncommitted changes")
        return notes


def compare(baseline: BenchmarkRecord, candidate: BenchmarkRecord) -> Comparison:
    return Comparison(baseline=baseline, candidate=candidate)


# --- Running the thing -----------------------------------------------------


def missing_images(rows: list[GoldRow], images_dir: Path) -> list[str]:
    return [
        name for row in rows for name in row.images
        if not (Path(images_dir) / name).is_file()
    ]


def missing_audio(rows: list[GoldRow], audio_dir: Path) -> list[str]:
    """Audio filenames named by a row but absent from disk.

    Only rows that name one are checked: a blank `audio` is the documented
    "never escalates" case, not a missing file.
    """
    return [
        row.audio for row in rows
        if row.audio and not (Path(audio_dir) / row.audio).is_file()
    ]


def attach_gold(traces: "list[UnitTrace]", rows: list[GoldRow]) -> None:
    """Join gold labels onto traces, by position.

    Position, not id: pipeline.run preserves input order, and two gold rows may
    legitimately name the same video. Gold on the trace is what lets the graph
    colour a node by agreement without the renderer knowing what a GoldRow is.
    """
    for trace, row in zip(traces, rows):
        if trace is None:
            continue
        trace.gold = {"is_ad": row.is_ad, "has_food": row.has_food,
                      "is_upf": row.is_upf}


def execute(cfg: Config, rows: list[GoldRow], images_dir: Path,
            audio_dir: Path | None = None,
            trace_sink: "list[UnitTrace] | None" = None):
    """Run the real pipeline over the evaluable gold rows and score the result.

    Returns (report, summary). Reuses pipeline.run unchanged — the point is to
    measure the pipeline as it actually runs, not a parallel copy that drifts.
    """
    usable = evaluable(rows)
    if not usable:
        raise BenchmarkError(
            "No usable rows in the gold set — every row is either unlabelled "
            "or disputed. Fill in is_ad / has_food / is_upf first."
        )
    missing = missing_images(usable, images_dir)
    if missing:
        raise BenchmarkError(
            f"Missing image files in {images_dir}: {', '.join(missing)}"
        )

    # A row with neither field filled in must still get meta=None, not a
    # VideoMeta of two empty strings — gold.csv rows written before title/
    # description existed (and any row nobody has filled in yet) would
    # otherwise silently switch to ad_agent's metadata-aware prompt variant,
    # moving the benchmark numbers for a reason unrelated to the code change
    # actually under test.
    bundles = [
        Bundle(
            images=[Path(images_dir) / name for name in row.images],
            meta=agents.VideoMeta(title=row.title, description=row.description)
            if (row.title or row.description) else None,
            # A row with no audio filename gets None and never escalates, so
            # every gold row written before this feature scores exactly as it
            # did — the before/after comparison stays a comparison of the
            # change under test rather than a re-baseline.
            audio=(audio_dir / row.audio) if (row.audio and audio_dir) else None,
        )
        for row in usable
    ]
    results, summary = run(cfg, bundles)

    # Opt-in by passing a list: a caller that does not want traces pays
    # nothing for them, and execute's return signature is unchanged for every
    # existing caller and test.
    if trace_sink is not None:
        traces = [r.trace for r in results if r.trace is not None]
        attach_gold(traces, usable)
        trace_sink.extend(traces)

    predictions = {
        "|".join(Path(p).name for p in result.image_paths): {
            "is_ad": result.is_ad, "has_food": result.has_food,
            "is_upf": result.is_upf, "error": result.error,
            "audio_error": result.audio_error,
            "audio_is_ad": result.audio_is_ad,
            # None on a run without rationale; score_predictions treats that
            # the same as an absent key.
            "is_ad_reason": result.is_ad_reason,
            "has_food_reason": result.has_food_reason,
            "is_upf_reason": result.is_upf_reason,
        }
        for result in results
    }
    report = score_predictions(
        rows, predictions, model=cfg.model, mode=cfg.mode,
        total_cost_usd=summary.total_cost_usd, rationale=cfg.rationale,
        audio_escalation=cfg.audio_escalation,
        stt_model=cfg.model_for_agent("transcribe") if cfg.audio_escalation else "",
    )
    return report, summary


def run_benchmark(
    cfg: Config,
    rows: list[GoldRow],
    images_dir: Path,
    *,
    audio_dir: Path | None = None,
    version: str,
    notes: str = "",
    gold_path: Path | None = None,
    directory: Path | None = None,
    persist: bool = True,
) -> tuple[BenchmarkRecord, Path | None]:
    """Execute, score, stamp, and (by default) save. The one call the UI needs."""
    started = time.monotonic()
    traces: list[UnitTrace] = []
    report, summary = execute(cfg, rows, images_dir, audio_dir,
                              trace_sink=traces)
    record = record_from_report(
        report,
        version=version,
        notes=notes,
        n_units=len(rows),
        total_prompt_tokens=summary.total_prompt_tokens,
        total_completion_tokens=summary.total_completion_tokens,
        duration_seconds=time.monotonic() - started,
        n_escalations=summary.n_escalations,
        audio_cost_usd=summary.audio_cost_usd,
        gold_path=gold_path,
    )
    path = save(record, directory) if persist else None
    if persist:
        # Beside the record, keyed by its id. Written after the record so a
        # trace file never exists for a benchmark that failed to save.
        save_traces(record.benchmark_id, traces, benchmarks_dir(directory))
    return record, path


__all__ = [
    "BENCHMARKS_DIR", "BenchmarkError", "BenchmarkRecord", "Comparison",
    "GitState", "LABEL_FIELDS", "benchmarks_dir", "compare", "delete",
    "execute", "find", "fingerprint", "git_state", "gold_fingerprint",
    "load_all",
    "missing_audio", "missing_images", "points",
    "prompt_fingerprint", "record_from_report", "run_benchmark",
    "attach_gold", "save", "suggest_version",
]
