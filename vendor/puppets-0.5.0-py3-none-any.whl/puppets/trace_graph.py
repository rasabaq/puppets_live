"""Turn traces into Graphviz DOT. Drawing only — no pipeline knowledge here.

A note on the font, because it is load-bearing. Graphviz computes every node's
size from its label *before* the browser draws anything, using built-in metrics
for a handful of known families. The app's stylesheet then restyles the SVG it
gets back, so if the drawn face is wider than the measured one, every label
spills outside its own box. Courier is declared here and the stylesheet pins
the rendered face to IBM Plex Mono: both are monospace at 0.6em per character,
so what Graphviz measured is what the browser draws. Changing either one
without the other brings the overflow back.

Two views, because a trace answers two different questions:

* ``unit_dot`` — one unit, one DAG. Which agent set which variable, what it
  said, what it cost, and (where gold is known) whether it was right. This is
  the "why did it get this one wrong" view.
* ``aggregate_dot`` — every unit in a run, collapsed onto the flow itself.
  Node and edge labels carry counts, so a branch that never fires, or a gate
  that drops half the population, is visible without reading a single unit.

Both emit DOT text. Streamlit renders it with ``st.graphviz_chart`` and
nothing needs the graphviz binary installed.
"""

from __future__ import annotations

from collections import Counter, defaultdict

from .trace import AGENT, ERROR, GATE, OK, SKIPPED, UnitTrace

# Colours match the app's palette: amber for the flow, green/red only ever
# meaning agreement/disagreement with gold, grey for "not asked".
_INK = "#011627"
_AGREE = "#1b998b"
_DISAGREE = "#e4572e"
_UNKNOWN = "#8a9ba8"
_ERROR_LINE = "#e4572e"
_FILL = "#fdfffc"
_AMBER = "#ffc14d"


# The face Graphviz measures with. See the module docstring: it must stay in
# step with the one the stylesheet paints, or labels overflow their boxes.
_FONT = "Courier"


def _preamble() -> list[str]:
    """Graph-wide attributes shared by both views."""
    return [
        # Left to right: the pipeline is a sequence of stages, and stacking it
        # vertically buried the gate conditions in a narrow column.
        "  rankdir=LR;",
        # Generous rank separation because the edge labels (the gate
        # conditions) live in the gaps between ranks; too little and they land
        # on top of the nodes they run past.
        '  ranksep="1.5 equally"; nodesep="0.45";',
        '  bgcolor="transparent";',
        '  splines="spline";',
        f'  node [fontname="{_FONT}", fontsize=10, style="filled", '
        f'fillcolor="{_FILL}", color="{_INK}", margin="0.22,0.14"];',
        f'  edge [fontname="{_FONT}", fontsize=9, color="{_INK}", '
        f'fontcolor="{_INK}"];',
    ]


def _escape(text: object) -> str:
    return str(text).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")


def _wrap(text: str, width: int = 30, max_lines: int = 3) -> str:
    """Hard-wrap a rationale so a node stays a node and not a paragraph."""
    words, lines, current = str(text).split(), [], ""
    for word in words:
        if len(current) + len(word) + 1 > width:
            lines.append(current)
            current = word
            if len(lines) == max_lines:
                # Real newlines here; _escape turns them into DOT's \n later.
                return "\n".join(lines) + "…"
        else:
            current = f"{current} {word}".strip()
    if current:
        lines.append(current)
    return "\n".join(lines)


def _value_text(value: object) -> str:
    return "null" if value is None else str(value)


def _status_colour(trace: UnitTrace, step) -> str:
    """Green/red against gold, grey when there is nothing to compare."""
    if step.status == SKIPPED:
        return _UNKNOWN
    agrees = trace.step_agrees(step)
    if agrees is None:
        return _INK if not step.variable else _UNKNOWN
    return _AGREE if agrees else _DISAGREE


def step_detail(trace: UnitTrace, step) -> dict:
    """Everything a step knows, untruncated, as plain display fields.

    The node label is a summary — wrapped, clipped, sized to fit a graph. This
    is the same step with nothing left out, for the panel that opens when a
    node is clicked and for the hover tooltip. Values are strings because the
    only consumers render them; None becomes "" rather than "None".
    """
    agrees = trace.step_agrees(step)
    return {
        "id": step.id,
        "label": step.label or step.id,
        "kind": step.kind,
        "summary": "",
        "mode": "",
        # Only when it is worth saying: every node that is not marked
        # otherwise ran fine, so printing "ok" on all of them is noise.
        "status": "" if step.status == OK else step.status,
        "variable": step.variable or "",
        "value": "" if step.value is None else _value_text(step.value),
        "gold": ("" if not step.variable or step.variable not in trace.gold
                 or trace.gold.get(step.variable) is None
                 else _value_text(trace.gold[step.variable])),
        "agrees": "" if agrees is None else ("yes" if agrees else "no"),
        "reason": step.reason or "",
        "error": step.error or "",
        "model": step.model or "",
        "condition": step.condition or "",
        "after": ", ".join(step.inputs) or "start",
        "cost": f"${step.cost_usd:.4f}" if step.cost_usd else "",
        "duration": (f"{step.duration_seconds:.1f}s"
                     if step.duration_seconds else ""),
        "tokens": (f"{step.prompt_tokens} in / {step.completion_tokens} out"
                   if step.prompt_tokens or step.completion_tokens else ""),
    }


def _tooltip(trace: UnitTrace, step, *, show_reasons: bool = True) -> str:
    """The hover text: the whole reason, so the static chart is readable too.

    Graphviz writes this into the SVG as a <title>, which every browser shows
    on hover with no scripting at all. It is what the graph falls back to when
    the interactive view is switched off — so it honours ``show_reasons`` for
    the same reason the label does: unticking it means the reasons are not
    wanted, not that they moved somewhere less visible.
    """
    detail = step_detail(trace, step)
    lines = [detail["label"]]
    if detail["variable"]:
        lines.append(f'{detail["variable"]} = {detail["value"] or "null"}'
                     + (f' (gold {detail["gold"]})' if detail["gold"] else ""))
    for key in ("model", "error", "reason"):
        if key == "reason" and not show_reasons:
            continue
        if detail[key]:
            lines.append(detail[key])
    return "\n".join(lines)


def unit_detail(trace: UnitTrace) -> dict:
    """Every node in ``unit_dot``, keyed by the id the SVG carries.

    Includes the start node, which is not a step: clicking the unit itself
    should say which unit it is and how it ended up, not do nothing.
    """
    detail = {step.id: step_detail(trace, step) for step in trace.steps}
    labels = []
    for variable, value in trace.labels.items():
        text = f"{variable} = {_value_text(value)}"
        gold = trace.gold.get(variable)
        if trace.agrees(variable) is False:
            text += f"  (gold {_value_text(gold)})"
        labels.append(text)
    detail["__start"] = {
        "id": "__start",
        "label": trace.unit_label or trace.unit_id,
        "kind": "unit",
        "status": "error" if trace.error else "",
        "variable": "", "value": "", "gold": "", "agrees": "",
        "summary": "\n".join(labels),
        "mode": trace.mode or "",
        "reason": "",
        "error": trace.error or "",
        "model": trace.model or "",
        "condition": "",
        "after": "",
        "cost": f"${sum(s.cost_usd for s in trace.steps):.4f}",
        "duration": "",
        "tokens": "",
    }
    return detail


def unit_dot(trace: UnitTrace, *, show_reasons: bool = True) -> str:
    """One unit's decision DAG."""
    lines = [
        "digraph unit {",
        *_preamble(),
    ]

    # The unit's own name can be three pipe-joined filenames, which is wider
    # than any other node in the graph; wrapped, it anchors the left edge
    # instead of stretching the first rank across the page.
    head_parts = [_wrap(trace.unit_label or trace.unit_id, width=26, max_lines=4)]
    if trace.model:
        head_parts.append(trace.model)
    head = "\\n".join(_escape(p) for p in head_parts)
    lines.append(
        f'  __start [label="{head}", shape="box", '
        f'style="filled,rounded", fillcolor="{_AMBER}", color="{_AMBER}"];'
    )

    for step in trace.steps:
        colour = _status_colour(trace, step)
        parts = [step.label or step.id]
        if step.variable:
            parts.append(f"{step.variable} = {_value_text(step.value)}")
        elif step.value is not None and step.status == OK:
            # A step with no variable of its own still answered something —
            # the audio agent's vote, the fetch's cache hit — and a node that
            # showed only its cost would be saying nothing.
            parts.append(_value_text(step.value))
        if step.status == ERROR:
            parts.append(f"error: {step.error or 'failed'}")
        elif step.status == SKIPPED:
            parts.append("not run")
        if step.status == OK and (step.cost_usd or step.duration_seconds):
            # Transcription is a tool, not an agent, but it is billed like one
            # and is often the slowest step in the flow — leaving it off the
            # node would hide the price of escalating.
            meter = [f"${step.cost_usd:.4f}", f"{step.duration_seconds:.1f}s"]
            tokens = step.prompt_tokens + step.completion_tokens
            if tokens:
                meter.append(f"{tokens} tok")
            parts.append(" · ".join(meter))
        if show_reasons and step.reason:
            parts.append(_wrap(step.reason))

        # Gold disagreement is the one thing worth spelling out on the node:
        # a red border says "wrong", this says what right would have been.
        if trace.step_agrees(step) is False:
            parts.append(f"gold = {_value_text(trace.gold.get(step.variable))}")

        # Boxes for anything carrying text. An ellipse or a diamond sized to
        # fit a three-line label is enormous and mostly empty, so the branch
        # steps are marked by a dashed border instead of by a shape.
        shape = "box"
        style = ("filled,rounded,dashed" if step.kind == GATE
                 else "filled,rounded")
        penwidth = 2.4 if step.status == ERROR else 1.4
        border = _ERROR_LINE if step.status == ERROR else colour
        label = "\\n".join(_escape(p) for p in parts)
        lines.append(
            f'  "{_escape(step.id)}" [label="{label}", shape="{shape}", '
            f'style="{style}", color="{border}", penwidth={penwidth}, '
            f'fontcolor="{_INK}", tooltip="{_escape(_tooltip(trace, step, show_reasons=show_reasons))}"];'
        )

    for step in trace.steps:
        sources = step.inputs or ["__start"]
        for source in sources:
            attrs = [f'label="{_escape(step.condition)}"'] if step.condition else []
            if step.status == SKIPPED:
                attrs.append('style="dashed"')
                attrs.append(f'color="{_UNKNOWN}"')
            suffix = f' [{", ".join(attrs)}]' if attrs else ""
            lines.append(f'  "{_escape(source)}" -> "{_escape(step.id)}"{suffix};')

    lines.append("}")
    return "\n".join(lines)


def _aggregate_nodes(traces: "list[UnitTrace]") -> dict:
    """Collapse every unit's steps onto the flow, keeping counts per step."""
    nodes: dict = {}
    for trace in traces:
        for step in trace.steps:
            node = nodes.setdefault(step.id, {
                "label": step.label or step.id,
                "kind": step.kind,
                "variable": step.variable,
                "n": 0, "n_error": 0, "n_skipped": 0,
                "values": Counter(), "cost": 0.0, "duration": 0.0,
                "agree": 0, "disagree": 0,
            })
            node["n"] += 1
            node["cost"] += step.cost_usd
            node["duration"] += step.duration_seconds
            if step.status == ERROR:
                node["n_error"] += 1
            elif step.status == SKIPPED:
                node["n_skipped"] += 1
            else:
                node["values"][_value_text(step.value)] += 1
            agrees = trace.step_agrees(step)
            if agrees is not None:
                if agrees is True:
                    node["agree"] += 1
                elif agrees is False:
                    node["disagree"] += 1
    return nodes


def aggregate_dot(traces: "list[UnitTrace]") -> str:
    """The whole run on one flow: counts on the nodes, population on the edges."""
    if not traces:
        return "digraph empty { }"

    nodes = _aggregate_nodes(traces)
    edges: dict = defaultdict(lambda: {"n": 0, "condition": ""})
    for trace in traces:
        for step in trace.steps:
            if step.status == SKIPPED:
                continue
            for source in (step.inputs or ["__start"]):
                edge = edges[(source, step.id)]
                edge["n"] += 1
                edge["condition"] = step.condition or edge["condition"]

    lines = [
        "digraph flow {",
        *_preamble(),
        f'  __start [label="{len(traces)} unit(s)", shape="box", '
        f'style="filled,rounded", fillcolor="{_AMBER}", color="{_AMBER}"];',
    ]

    for step_id, node in nodes.items():
        ran = node["n"] - node["n_skipped"]
        parts = [node["label"], f"ran on {ran}/{len(traces)}"]
        if node["values"]:
            spread = ", ".join(
                f"{value} ×{count}" for value, count in node["values"].most_common()
            )
            # A step with a variable is named by it; one without already says
            # what it answered inside its own value, so prefixing that with
            # "value:" would only add a word.
            parts.append(f"{node['variable']}: {spread}" if node["variable"]
                         else spread)
        total = node["agree"] + node["disagree"]
        if total:
            parts.append(
                f"agrees {node['agree']}/{total} ({node['agree'] / total:.0%})"
            )
        if node["n_error"]:
            parts.append(f"{node['n_error']} error(s)")
        if node["cost"]:
            parts.append(f"${node['cost']:.4f} total")

        if not total:
            colour = _ERROR_LINE if node["n_error"] else _UNKNOWN
        else:
            # One colour for the node, scaled by how often it is right:
            # anything under 90% agreement is worth looking at.
            colour = _AGREE if node["agree"] / total >= 0.9 else _DISAGREE
        shape = "box"
        style = ("filled,rounded,dashed" if node["kind"] == GATE
                 else "filled,rounded")
        label = "\\n".join(_escape(p) for p in parts if p)
        lines.append(
            f'  "{_escape(step_id)}" [label="{label}", shape="{shape}", '
            f'style="{style}", color="{colour}", penwidth=1.6];'
        )

    for (source, target), edge in edges.items():
        bits = [f"{edge['n']}"]
        if edge["condition"]:
            bits.insert(0, edge["condition"])
        width = 1.0 + 2.0 * (edge["n"] / max(1, len(traces)))
        lines.append(
            f'  "{_escape(source)}" -> "{_escape(target)}" '
            f'[label="{_escape(" · ".join(bits))}", penwidth={width:.1f}];'
        )

    lines.append("}")
    return "\n".join(lines)


__all__ = ["aggregate_dot", "step_detail", "unit_detail", "unit_dot"]
