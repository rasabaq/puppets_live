"""The labelling contract: prompt + strict JSON schema.

MVP scope is deliberately three variables and nothing else. No reasoning
fields, no self-reported confidence — this is the baseline that richer
schemas (reasoning-first fields, self-consistency voting) get measured
against later.
"""

from __future__ import annotations

LABEL_FIELDS = ("is_ad", "has_food", "is_upf")

# The has_food boundary. Shared for the same reason as IS_UPF_DEFINITION: the
# single-pass prompt and the per-agent prompts scope "where to look"
# differently, but "what counts as food" must be identical in all of them or
# the two flows measure different
# constructs. Codebook cases 1-3 and 5. Two tests, applied in this order:
# is a real food or drink being depicted at all (not a game asset, icon or
# metaphor), and — for moving imagery only — is the depicted food a food that
# exists. Photography and still artwork both count as depictions of food;
# animation additionally has to depict something real.
#
# Public name: also composed into the single-field food_agent prompt in
# agents.py, so the exclusion rule cannot drift between the single-pass and
# agent-per-* flows.
HAS_FOOD_EXCLUSIONS = """\
  Food or drink counts when it is depicted as something people actually eat \
or drink, or is the branding of such a product. Filmed or photographed food \
counts. Still artwork counts too — a drawing, illustration or painting of \
food is a depiction of food, and being hand-drawn rather than photographed \
never disqualifies it on its own.
  Moving imagery — animation, CGI, 3D rendering, game engines — carries one \
extra test: it counts only when the food it shows is a food that exists in \
the real world. An animated or rendered version of an everyday food or of a \
real brand's product counts. A dish invented for a fictional setting, with no \
real-world counterpart, does not, no matter how convincingly it is animated \
or rendered.
  Do NOT count, in any medium: food that exists only inside a video game or \
other virtual world (items, pickups, crafting ingredients, or food rendered \
in gameplay footage), no matter how photorealistic it looks, and regardless \
of whether the frame is a game ad or organic gameplay/let's-play content — a \
cooking or restaurant simulator is not food content; food-shaped sprites, characters or \
props that function as game assets rather than as food; food-shaped UI icons \
or emoji; or food used only as a metaphor or mascot for something else. Real \
food physically present in a gaming video, such as a creator eating on \
camera, still counts. A real food or drink brand's logo DOES count even when \
no product is visible, because brand marks are themselves the marketing \
exposure being measured.\
"""

# What "the thing being labelled" is, stated once and composed into every
# system prompt here and in agents.py.
#
# There used to be two of every prompt — a single-screenshot variant and a
# bundle-of-frames variant — differing only in these framing sentences while
# duplicating the whole codebook. One unit type replaces both: a lone
# screenshot is simply a unit of one image, so the prompts say "one or more"
# once instead of saying everything twice.
UNIT_DEFINITION = """\
The attached image or images are ONE unit to be labelled. A unit is either a \
single screenshot, or several consecutive frames sampled from ONE video — the \
user turn says which. When it is several frames they describe one video, and \
you return ONE set of labels for the video as a whole, never one set per frame.\
"""

# The closing scope + tie-break + output rule, shared for the same reason.
# "the attached image or images" is deliberate: it is true of a unit of one
# and a unit of twenty, so it does not need a variant per unit size.
#
# `tie_break` is the only thing that varies between callers — the combined
# prompt can return null for is_upf, a single-field agent prompt for is_ad or
# has_food cannot — so it is an argument rather than an excuse for a second
# copy of the paragraph.
def judge_only_what_is_visible(tie_break: str = "0, or null for is_upf") -> str:
    return (
        "Judge only what is visible in the attached image or images. Do not "
        "infer beyond them. When genuinely ambiguous prefer the more "
        f"conservative label ({tie_break}). Respond only with the JSON object "
        "required by the schema."
    )

# Shared substance. The NOVA framework classification lives here and only
# here — the single-pass prompt and the standalone upf_agent prompt in
# agents.py both compose it in, rather than each restating (and
# risking drift on) the NOVA group lists.
NOVA_CLASSIFICATION = """\
  1 if the most prominent food or drink is ultra-processed (NOVA group 4): \
industrial formulations such as soft drinks, packaged snacks, sweetened cereals, \
confectionery, instant noodles, reconstituted meat products, packaged breads and \
baked goods, sweetened dairy drinks and most fast food.
  0 if it is unprocessed, minimally processed, a culinary ingredient, or simply \
processed (NOVA groups 1-3): fresh or frozen fruit and vegetables, plain meat, \
eggs, milk, dried legumes, rice, oils, cheese, freshly baked bread, canned \
vegetables in brine.\
"""

IS_UPF_DEFINITION = """\
is_upf
  Applies only when has_food is 1. Use the NOVA framework.
""" + NOVA_CLASSIFICATION + """
  null if has_food is 0, or if the food cannot be identified well enough to \
classify.\
"""

# The combined statement of all three variables in one prompt.
#
# No API call sends this any more: the single-pass mode it belonged to is
# gone, and every label now comes from a focused agent in agents.py. It is
# kept for two reasons. It is the one place the three variable definitions
# are stated together, which is what the agent prompts are checked against
# so they cannot drift; and benchmarks.prompt_fingerprint hashes it, so
# deleting it would move every fingerprint and falsely flag every committed
# benchmark as not comparable when nothing about the agent contract changed.
#
# One prompt, not one per unit size. UNIT_DEFINITION carries the "one
# screenshot or many frames of one video" distinction, and each variable below
# is worded to hold either way ("anywhere in the unit"), so there is nothing
# left for a second copy to say differently.
SYSTEM_PROMPT = "\n\n".join([
    """\
You label units from a YouTube viewing session for a public-health audit \
of ultra-processed food marketing.

""" + UNIT_DEFINITION + """

For each unit assign exactly three variables:""",
    """\
is_ad
  1 if the unit shows commercial advertising content anywhere: a \
pre-roll/mid-roll video ad, a banner or overlay ad, a sponsored/promoted \
placement, or a shopping panel. 0 if it shows only organic content (a normal \
video, the home feed, search results, comments) with no advertising in view.""",
    """\
has_food
  1 if any food or drink product intended for human consumption is visible \
anywhere in the unit, or is the subject of the content — packaged products, \
prepared dishes, ingredients, beverages, or a food brand's logo/branding. \
0 otherwise.
""" + HAS_FOOD_EXCLUSIONS,
    IS_UPF_DEFINITION,
    judge_only_what_is_visible(),
])

# NOTE, for every response schema in this project (see the field schemas in
# agents.py): no `enum` on the integer label fields. Gemini's structured-output
# validator only accepts enum on string properties; it drops any property it
# rejects and then fails the request with "schema at top-level requires
# unspecified property 'is_ad'". The permitted values are stated in the field
# descriptions instead and enforced after parsing, in pipeline._apply_labels.

# --- Optional rationale ----------------------------------------------------
#
# Off by default, and deliberately so: the docstring at the top of this module
# describes a three-variable baseline that richer schemas get measured
# against. A rationale is a schema change, so a run with it on is a different
# arm of that experiment, not extra logging on the same run — it moves
# prompt_fingerprint (see benchmarks.prompt_fingerprint) precisely so the two
# cannot be silently compared.
#
# The reason field for a variable is emitted AFTER that variable, and the
# instruction says to label first and explain second. That ordering is the
# whole design: a reason generated BEFORE its label is chain-of-thought and
# would change the labels themselves, which is a separate experiment
# (reasoning-first) worth running on purpose rather than stumbling into while
# trying to find out why a label was wrong.

REASON_SUFFIX = "_reason"
REASON_FIELDS = tuple(f + REASON_SUFFIX for f in LABEL_FIELDS)

REASON_INSTRUCTION = """\
Alongside each label, fill in its matching _reason field: ONE short sentence, \
25 words at most, naming the specific thing you saw that decided that label \
("a soft-drink can on the desk", "the dish is an invented one from the game \
being played"). Assign the label first, then describe what \
decided it — the reason records a judgement you have already made, it does \
not replace making it. Do not restate the rule in the abstract, do not \
speculate beyond what you can see, and never leave a reason empty.\
"""


def reason_property(field: str) -> dict:
    return {
        "type": "string",
        "description": (
            f"One short sentence (25 words max) naming what decided the "
            f"{field} label. Written after {field}, never instead of it."
        ),
    }


def with_reason(prompt: str) -> str:
    """Today's prompt plus the rationale instruction.

    Composed at call time rather than baked into each agent prompt, so the
    rationale-off prompts stay byte-identical to the ones every existing
    benchmark record was measured with.
    """
    return prompt + "\n\n" + REASON_INSTRUCTION
