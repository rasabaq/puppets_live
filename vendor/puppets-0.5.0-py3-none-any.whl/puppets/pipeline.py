"""Labelling pipeline: bundles of 1-20 screenshots in, labelled records out."""

from __future__ import annotations

import json
import logging
import threading
import time
import uuid
from concurrent.futures import Executor, ThreadPoolExecutor
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path

from . import agents
from .audio import (
    AudioError,
    Transcript,
    audio_format,
    fingerprint as audio_fingerprint,
    load_transcript,
    store_transcript,
)
from .config import REPO_ROOT, Config
from .openrouter import OpenRouterError, complete, transcribe
from .schema import (
    LABEL_FIELDS,
    REASON_FIELDS,
)
from .trace import AGENT, ERROR, GATE, OK, SKIPPED, TOOL, Step, UnitTrace

logger = logging.getLogger(__name__)

# Where transcripts are cached, keyed by audio content hash + STT model.
# A module-level constant rather than a Config field: it is a location on
# disk, not a property of the labelling contract, and nothing about a run's
# results depends on it. Tests point it at a temp directory.
TRANSCRIPT_CACHE_DIR = REPO_ROOT / "runs" / "transcripts"

# Name of the transcription step in generation ids, raw responses and error
# messages. Not "transcribe_agent": it is a speech-to-text call with no
# prompt, not one of the prompted agents in agents.py.
TRANSCRIBE_STEP = "transcribe"

# How much of a transcript a trace keeps. The whole thing would make the trace
# file the largest artefact in the repo for no gain: this is enough to read
# what the audio agent judged, and the raw response still holds the full text.
TRANSCRIPT_TRACE_CHARS = 1200


@dataclass(frozen=True)
class Bundle:
    """A unit of images to label, plus optional video metadata and audio.

    meta flows to all three agents (see agents.AgentSpec.uses_metadata, True
    for each, and the per-variable metadata paragraphs in agents.py). Most
    bundles carry meta=None: every caller before this feature (and any upload
    with no title/description available) gets exactly today's prompts.

    audio is the video's audio track, used only by the escalation stage and
    only when Config.audio_escalation is on. Like meta it defaults to None,
    so a bundle without it behaves exactly as it did before this existed.
    """

    images: list[Path]
    meta: "agents.VideoMeta | None" = None
    audio: Path | None = None


def _normalize_bundles(bundles: "list[list[Path]] | list[Bundle]") -> list[Bundle]:
    """Accept the plain list[list[Path]] every existing caller passes, a
    list[Bundle] with metadata attached, or a mix of the two — each entry is
    normalized independently, so a bare list of Paths becomes Bundle(images=...,
    meta=None), leaving a Bundle already in the list untouched."""
    return [b if isinstance(b, Bundle) else Bundle(images=list(b)) for b in bundles]


@dataclass
class LabelResult:
    """One labelled unit — a bundle of one image, or of many."""

    image_paths: list[str]
    bundle_id: str
    is_ad: int | None = None
    has_food: int | None = None
    is_upf: int | None = None
    # Populated only when the run has rationale enabled (Config.rationale);
    # None on a default run, which is why they are not in LABEL_FIELDS and
    # nothing downstream may treat them as labels.
    is_ad_reason: str | None = None
    has_food_reason: str | None = None
    is_upf_reason: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    generation_id: str | None = None
    error: str | None = None
    # Why the audio channel produced no verdict: no audio attached is simply
    # None (not an error), but a missing file, an unsupported format, a
    # failed transcription or speechless audio all land here.
    #
    # Deliberately NOT folded into `error`: audio failing leaves the primary
    # labels completely intact, and `error` feeds n_errors, which feeds
    # benchmark coverage. Counting an unreadable audio file as a labelling
    # error would silently shrink the denominator of every benchmark.
    audio_error: str | None = None
    # The share of cost_usd spent on the audio channel. Already included in
    # cost_usd — carried separately so the price of escalation is visible
    # rather than buried in a total, which is the only way to tell whether
    # the feature is worth what it costs.
    audio_cost_usd: float = 0.0
    # The audio channel's own is_ad verdict, or None when the channel never
    # reached a verdict (not attached, not escalated, or audio_error set).
    #
    # Kept separate from is_ad because is_ad alone cannot answer "did the
    # audio flow do anything here": a 1 there might have come from the visual
    # pass. audio_is_ad == 1 is exactly the set of units the audio channel
    # promoted, since escalation only runs where is_ad was not already 1.
    audio_is_ad: int | None = None
    raw_response: dict | None = field(default=None, repr=False)
    # How this unit reached its labels: which agent set what, which gates
    # fired, what each call cost. Populated on every run (building it is a
    # few dataclasses, not an API call); dropped from as_row so the CSV is
    # unchanged, and persisted separately by the benchmark. See trace.py.
    trace: "UnitTrace | None" = field(default=None, repr=False)

    @property
    def n_images(self) -> int:
        return len(self.image_paths)

    def as_row(self) -> dict:
        row = asdict(self)
        row.pop("raw_response")
        row.pop("trace")
        return row


def _coerce_label(value: object) -> int | None:
    """Return 0/1, or None for anything else.

    The JSON schema cannot pin these to {0, 1} — see the note in schema.py —
    so an out-of-range value is treated as missing rather than recorded as data.
    """
    if isinstance(value, bool):
        return int(value)
    if isinstance(value, int) and value in (0, 1):
        return value
    return None


def _coerce_reason(value: object) -> str | None:
    """Return a non-empty stripped string, or None.

    An empty or whitespace-only reason is recorded as absent rather than as
    an empty string, so "the model gave no reason" and "rationale was off for
    this run" read the same downstream instead of being two near-identical
    states to handle.
    """
    if not isinstance(value, str):
        return None
    return value.strip() or None


def _apply_labels(result: LabelResult, labels: dict) -> None:
    for field_name in LABEL_FIELDS:
        setattr(result, field_name, _coerce_label(labels.get(field_name)))
    for field_name in REASON_FIELDS:
        setattr(result, field_name, _coerce_reason(labels.get(field_name)))
    # Enforce the measurement rule the schema can only ask for politely.
    if result.has_food == 0:
        result.is_upf = None
        # The is_upf reason goes with it: keeping a justification for a label
        # that was just overridden to null would be a record of a judgement
        # the run did not actually make.
        result.is_upf_reason = None
    missing = [f for f in ("is_ad", "has_food") if getattr(result, f) is None]
    if missing:
        result.error = f"Model returned no usable value for: {', '.join(missing)}"


@dataclass
class _AgentCallResult:
    """The outcome of one focused agent's API call."""

    value: object = None
    reason: str | None = None
    # Only audio_ad_agent sets this: the verbatim sentence that decided a
    # spoken-disclosure verdict. Not surfaced as a CSV column, but persisted
    # with the rest of the raw response.
    quote: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0
    cost_usd: float = 0.0
    generation_id: str | None = None
    raw: dict | None = None
    error: str | None = None
    # Wall-clock for this one call. Latency is per-agent, and a trace that
    # could not say which agent is the slow one would not explain a run's
    # duration.
    duration_seconds: float = 0.0


def _stamp(call: "_AgentCallResult", started: float) -> "_AgentCallResult":
    """Record how long a call took, on every exit path."""
    call.duration_seconds = round(time.monotonic() - started, 3)
    return call


def _run_agent(cfg: Config, spec: "agents.AgentSpec", images: list[Path],
               meta: "agents.VideoMeta | None" = None) -> _AgentCallResult:
    call = _AgentCallResult()
    started = time.monotonic()
    try:
        # meta is passed to every spec uniformly here — it is spec.uses_metadata
        # that decides whether it reaches the prompt, and which of the spec's
        # two system-prompt variants and which evidence clause it gets. All
        # three specs opt in today; a spec that did not would be unaffected.
        completion = complete(
            cfg,
            images=images,
            system_prompt=spec.system_prompt_for(meta=meta, reason=cfg.rationale),
            user_text=spec.user_text(n_images=len(images), meta=meta),
            response_format=spec.schema_for(reason=cfg.rationale),
            model=cfg.model_for_agent(spec.name),
        )
    except OpenRouterError as exc:
        call.error = str(exc)
        logger.exception("%s call failed: %s", spec.name, exc)
        return _stamp(call, started)

    call.prompt_tokens = completion.usage.prompt_tokens
    call.completion_tokens = completion.usage.completion_tokens
    call.cost_usd = completion.usage.cost_usd
    call.generation_id = completion.generation_id
    call.raw = completion.raw
    try:
        parsed = completion.parsed()
        call.value = parsed.get(spec.field)
        call.reason = _coerce_reason(parsed.get(spec.reason_field))
    except OpenRouterError as exc:
        call.error = str(exc)
        logger.exception("%s returned unparsable response: %s", spec.name, exc)
    return _stamp(call, started)


# One lock per distinct audio file, so that concurrent units sharing audio
# transcribe it once between them rather than once each.
#
# This is not a micro-optimisation. Split a video's frames into one bundle
# each — the per-frame granularity that used to be its own mode — and those
# units run concurrently while all carrying the same audio, so without this a
# 5-frame video escalating would miss the cache five times simultaneously and
# pay for five identical transcriptions. The cache alone cannot prevent that:
# it is a check-then-act, and all five threads check before any of them acts.
#
# The lock is held across the API call on purpose. The threads that block are
# ones whose only alternative is duplicating work already in flight; when they
# wake they read the cache and proceed.
_transcript_locks: dict[str, threading.Lock] = {}
_transcript_locks_guard = threading.Lock()


def _transcript_lock(key: str) -> threading.Lock:
    with _transcript_locks_guard:
        return _transcript_locks.setdefault(key, threading.Lock())


def _run_transcribe(cfg: Config, audio_path: Path) -> tuple[Transcript | None,
                                                            _AgentCallResult, int]:
    """Transcribe one audio file, via the cache where possible.

    Returns (transcript, call, n_api_calls). n_api_calls is 0 on a cache hit
    and on a failure that happened before anything was sent, so the run
    summary counts calls that actually occurred rather than escalations that
    were attempted.
    """
    call = _AgentCallResult()
    model = cfg.model_for_agent(TRANSCRIBE_STEP)

    try:
        # Validate the format here rather than leaving it to the request
        # builder. Both checks are about this file being usable at all, and
        # neither depends on the API — finding out that a .opus is
        # unsupported belongs at the point of escalation, not three frames
        # deep in a call stack that is about to upload megabytes.
        audio_format(audio_path)
        key = audio_fingerprint(audio_path)
    except AudioError as exc:
        call.error = str(exc)
        logger.exception("audio prep failed for %s: %s", audio_path, exc)
        return None, call, 0

    with _transcript_lock(key):
        return _transcribe_uncached(cfg, audio_path, key, model, call)


def _transcribe_uncached(cfg: Config, audio_path: Path, key: str, model: str,
                         call: _AgentCallResult) -> tuple[Transcript | None,
                                                          _AgentCallResult, int]:
    """The cache check and, on a miss, the call. Runs under this audio's lock."""
    cached = load_transcript(TRANSCRIPT_CACHE_DIR, key, model)
    if cached is not None:
        logger.debug("transcript cache hit for %s (model=%s)", audio_path.name, model)
        return cached, call, 0

    logger.info("transcribing %s with %s", audio_path.name, model)
    started = time.monotonic()
    try:
        result = transcribe(
            cfg, audio=audio_path, model=model, language=cfg.stt_language
        )
    except (OpenRouterError, AudioError) as exc:
        call.error = str(exc)
        logger.exception("transcription failed for %s: %s", audio_path.name, exc)
        return None, call, 0
    logger.info(
        "transcribed %s in %.1fs (%d chars)",
        audio_path.name, time.monotonic() - started, len(result.text),
    )

    call.prompt_tokens = result.usage.prompt_tokens
    call.completion_tokens = result.usage.completion_tokens
    call.cost_usd = result.usage.cost_usd
    call.raw = result.raw

    transcript = Transcript(
        text=result.text,
        # The model reports the language it detected, where it reports one at
        # all; cfg.stt_language is what we asked for, which is not the same
        # claim and should not be recorded as if it were.
        language=result.language,
        # Derived rather than self-reported: a recogniser returns words or it
        # does not. The caller distinguishes "nothing was said" from "nothing
        # came back" — see _escalate_to_audio, which has to guess between a
        # silent video and a language mismatch and says so.
        has_speech=bool(result.text),
        model=model,
        cost_usd=call.cost_usd,
        prompt_tokens=call.prompt_tokens,
        completion_tokens=call.completion_tokens,
    )
    store_transcript(TRANSCRIPT_CACHE_DIR, key, transcript)
    return transcript, call, 1


def _run_audio_ad(cfg: Config, transcript: Transcript,
                  meta: "agents.VideoMeta | None") -> _AgentCallResult:
    """Ask the text-only agent whether the speech discloses a promotion."""
    spec = agents.AUDIO_AD_AGENT
    call = _AgentCallResult()
    started = time.monotonic()
    try:
        completion = complete(
            cfg,
            images=[],
            system_prompt=spec.system_prompt_for(reason=cfg.rationale),
            user_text=agents.audio_ad_user_text(transcript.text, meta),
            response_format=spec.schema_for(reason=cfg.rationale),
            model=cfg.model_for_agent(spec.name),
        )
    except OpenRouterError as exc:
        call.error = str(exc)
        logger.exception("%s call failed: %s", spec.name, exc)
        return _stamp(call, started)

    call.prompt_tokens = completion.usage.prompt_tokens
    call.completion_tokens = completion.usage.completion_tokens
    call.cost_usd = completion.usage.cost_usd
    call.generation_id = completion.generation_id
    call.raw = completion.raw
    try:
        parsed = completion.parsed()
        call.value = parsed.get(spec.field)
        call.reason = _coerce_reason(parsed.get(spec.reason_field))
        call.quote = _coerce_reason(parsed.get("disclosure_quote"))
    except OpenRouterError as exc:
        call.error = str(exc)
        logger.exception("%s returned unparsable response: %s", spec.name, exc)
    return _stamp(call, started)


def _escalate_to_audio(cfg: Config, result: LabelResult, audio_path: Path,
                       meta: "agents.VideoMeta | None",
                       gen_ids: dict, raws: dict,
                       trace: "UnitTrace | None" = None) -> int:
    """Run the audio channel and, if it finds a promotion, flip is_ad to 1.

    Returns the number of API calls made — which is 0 on a pure cache hit, so
    it is a count of calls and not of escalations. Mutates `result` in place.

    Audio only ever turns 0 (or a missing verdict) into 1 — never 1 into 0.
    It is an additional evidence channel, the same shape as the metadata
    disclosure rule in CODEBOOK.md, so a positive from any channel stands and
    no cross-channel conflict resolution is needed.
    """
    n_calls = 0
    transcript, call, made = _run_transcribe(cfg, audio_path)
    n_calls += made
    result.audio_cost_usd += call.cost_usd
    _merge_agent_call(result, TRANSCRIBE_STEP, call, gen_ids, raws)
    if trace is not None:
        step = _agent_step(
            TRANSCRIBE_STEP, call, kind=TOOL,
            model=cfg.model_for_agent(TRANSCRIBE_STEP),
            inputs=["ad_agent"], condition="is_ad \u2260 1",
            value=("cached" if not made else "transcribed") if not call.error else None,
        )
        # The transcript is the evidence the next agent judges, so it belongs
        # on the step the same way a rationale does. Bounded, though: a
        # 10-minute video transcribes to tens of thousands of characters, and
        # every trace line is read back into memory to draw a graph. This much
        # is enough to see what the audio agent was working from — the graph
        # clips it to three lines, and clicking the node shows all of it.
        if transcript is not None and transcript.text:
            step.reason = transcript.text[:TRANSCRIPT_TRACE_CHARS]
        trace.add(step)
    if call.error:
        result.audio_error = f"{TRANSCRIBE_STEP}: {call.error}"
        logger.warning("audio escalation aborted: %s", result.audio_error)
        return n_calls
    if transcript is None or not transcript.has_speech or not transcript.text:
        # Not an error: a music-only or silent video is a real, correctly
        # transcribed thing with nothing for the next agent to judge. Recorded
        # so that "we listened and there was no speech" is distinguishable
        # from "we never got that far".
        # Empty is ambiguous with a dedicated recogniser, though less so now
        # that language is auto-detected: silence is the likely cause, and a
        # forced PUPPETS_STT_LANGUAGE that does not match the audio the
        # remaining one. Say both, rather than assert the wrong one.
        forced = (f", or its language is not the forced "
                  f"PUPPETS_STT_LANGUAGE={cfg.stt_language}"
                  if cfg.stt_language else "")
        result.audio_error = (
            f"transcript empty — the audio has no speech{forced}"
        )
        logger.warning("audio escalation: %s", result.audio_error)
        if trace is not None:
            trace.add(Step(
                id=agents.AUDIO_AD_AGENT.name, kind=AGENT,
                label=agents.AUDIO_AD_AGENT.name, status=SKIPPED,
                error=result.audio_error,
                inputs=[TRANSCRIBE_STEP], condition="no speech",
            ))
        return n_calls

    ad_call = _run_audio_ad(cfg, transcript, meta)
    n_calls += 1
    result.audio_cost_usd += ad_call.cost_usd
    _merge_agent_call(result, agents.AUDIO_AD_AGENT.name, ad_call, gen_ids, raws)
    if trace is not None:
        # variable is left None on purpose: this agent votes on is_ad but does
        # not set it. The override step below is what sets it, and only that
        # step should be scored against gold.
        step = _agent_step(
            agents.AUDIO_AD_AGENT.name, ad_call,
            model=cfg.model_for_agent(agents.AUDIO_AD_AGENT.name),
            inputs=[TRANSCRIBE_STEP], condition="speech found",
            value=f"audio_is_ad = {_coerce_label(ad_call.value)}",
        )
        if ad_call.quote:
            step.reason = f"\u201c{ad_call.quote}\u201d"
        trace.add(step)
    if ad_call.error:
        result.audio_error = f"{agents.AUDIO_AD_AGENT.name}: {ad_call.error}"
        return n_calls

    result.audio_is_ad = _coerce_label(ad_call.value)
    if result.audio_is_ad == 1:
        result.is_ad = 1
        # The ad_agent reason, if any, justified a 0 that is no longer the
        # label — keeping it would record a justification for a judgement the
        # run has since overturned. Same rule _apply_labels applies when
        # has_food == 0 clears is_upf_reason.
        result.is_ad_reason = ad_call.reason
        logger.info("audio escalation flipped is_ad 0 -> 1 (quote=%r)", ad_call.quote)
        if trace is not None:
            trace.add(Step(
                id="audio_override", kind=GATE, label="audio overrides is_ad",
                variable="is_ad", value=1, reason=ad_call.reason,
                inputs=[agents.AUDIO_AD_AGENT.name],
                condition="disclosure heard",
            ))
    return n_calls


def _agent_step(step_id: str, call: _AgentCallResult, *,
                kind: str = AGENT, variable: str | None = None,
                model: str = "", inputs: "list[str] | None" = None,
                condition: str = "", value: object = None) -> Step:
    """One agent call, as a trace step. Status comes from the call itself."""
    return Step(
        id=step_id,
        kind=kind,
        label=step_id,
        variable=variable,
        value=value if call.error is None else None,
        reason=call.reason,
        status=ERROR if call.error else OK,
        error=call.error,
        model=model,
        prompt_tokens=call.prompt_tokens,
        completion_tokens=call.completion_tokens,
        cost_usd=call.cost_usd,
        duration_seconds=call.duration_seconds,
        inputs=list(inputs or []),
        condition=condition,
    )


def _merge_agent_call(result: LabelResult, name: str, call: _AgentCallResult,
                       gen_ids: dict, raws: dict) -> None:
    result.prompt_tokens += call.prompt_tokens
    result.completion_tokens += call.completion_tokens
    result.cost_usd += call.cost_usd
    if call.generation_id is not None:
        gen_ids[name] = call.generation_id
    if call.raw is not None:
        raws[name] = call.raw


def _label_agent_unit(cfg: Config, pool: Executor, images: list[Path],
                       bundle_id: str,
                       meta: "agents.VideoMeta | None" = None,
                       audio: Path | None = None) -> tuple[LabelResult, int, bool]:
    """Label one unit (a bundle of one image, or of many) with the 3-agent flow.

    ad_agent and food_agent run concurrently on `pool`; upf_agent runs only
    if has_food == 1, and only after food_agent is known to have succeeded.

    `meta` is handed to all three agents' _run_agent calls below, and each
    folds it into its own prompt using its own metadata paragraph. A bundle
    with meta=None leaves every prompt at its base variant, so a run over
    metadata-less units is unaffected.
    """
    result = LabelResult(image_paths=[str(p) for p in images], bundle_id=bundle_id)
    trace = UnitTrace(
        unit_id=bundle_id,
        unit_label=" | ".join(Path(p).name for p in images),
        mode=cfg.mode,
        model=cfg.model,
    )
    result.trace = trace
    gen_ids: dict[str, str] = {}
    raws: dict[str, dict] = {}
    n_calls = 0
    started = time.monotonic()
    logger.info("labelling bundle %s: %d image(s)", bundle_id, len(images))

    ad_future = pool.submit(_run_agent, cfg, agents.AD_AGENT, images, meta)
    food_future = pool.submit(_run_agent, cfg, agents.FOOD_AGENT, images, meta)
    ad_call = ad_future.result()
    food_call = food_future.result()
    n_calls += 2
    _merge_agent_call(result, agents.AD_AGENT.name, ad_call, gen_ids, raws)
    _merge_agent_call(result, agents.FOOD_AGENT.name, food_call, gen_ids, raws)
    trace.add(_agent_step(
        agents.AD_AGENT.name, ad_call, variable="is_ad",
        model=cfg.model_for_agent(agents.AD_AGENT.name),
        value=_coerce_label(ad_call.value),
    ))
    trace.add(_agent_step(
        agents.FOOD_AGENT.name, food_call, variable="has_food",
        model=cfg.model_for_agent(agents.FOOD_AGENT.name),
        value=_coerce_label(food_call.value),
    ))

    errors = []
    if food_call.error:
        errors.append(f"{agents.FOOD_AGENT.name}: {food_call.error}")
        result.error = "; ".join(errors)
        result.generation_id = json.dumps(gen_ids) if gen_ids else None
        result.raw_response = raws or None
        trace.error = result.error
        trace.labels = {f: getattr(result, f) for f in LABEL_FIELDS}
        logger.warning(
            "bundle %s aborted after %.1fs: %s",
            bundle_id, time.monotonic() - started, result.error,
        )
        return result, n_calls, False
    if ad_call.error:
        errors.append(f"{agents.AD_AGENT.name}: {ad_call.error}")

    result.is_ad = _coerce_label(ad_call.value)
    result.has_food = _coerce_label(food_call.value)
    result.is_ad_reason = ad_call.reason
    result.has_food_reason = food_call.reason

    if result.has_food == 1:
        upf_call = pool.submit(_run_agent, cfg, agents.UPF_AGENT, images, meta).result()
        n_calls += 1
        _merge_agent_call(result, agents.UPF_AGENT.name, upf_call, gen_ids, raws)
        trace.add(_agent_step(
            agents.UPF_AGENT.name, upf_call, variable="is_upf",
            model=cfg.model_for_agent(agents.UPF_AGENT.name),
            value=_coerce_label(upf_call.value),
            inputs=[agents.FOOD_AGENT.name], condition="has_food = 1",
        ))
        if upf_call.error:
            errors.append(f"{agents.UPF_AGENT.name}: {upf_call.error}")
        else:
            result.is_upf = _coerce_label(upf_call.value)
            result.is_upf_reason = upf_call.reason
    else:
        # upf_agent never ran, so there is no is_upf_reason to record — the
        # null here is "not asked", matching is_upf itself.
        result.is_upf = None
        # Recorded as a skipped step rather than omitted: "upf_agent was never
        # asked" and "this run has no upf_agent" are different facts, and only
        # the first one explains a null is_upf.
        trace.add(Step(
            id=agents.UPF_AGENT.name, kind=AGENT, label=agents.UPF_AGENT.name,
            variable="is_upf", status=SKIPPED,
            inputs=[agents.FOOD_AGENT.name],
            condition=f"has_food = {result.has_food}",
        ))

    # The audio channel. Sequential, after the visual/metadata verdict is
    # known, so "transcriptions made" stays equal to "escalations" and the
    # cost line remains a direct check on this condition.
    #
    # The trigger is `!= 1`, not "ad_agent was unsure": an undisclosed
    # sponsorship has no #ad in its metadata and nothing commercial in frame,
    # so ad_agent returns a confident 0 on exactly the population this is
    # hunting. That `!= 1` also covers is_ad being None means a failed
    # ad_agent still gets a shot at a verdict here — its error stays recorded
    # either way, since an escalation that worked does not unmake a call that
    # failed.
    #
    # Placed before the `missing` check below so a label recovered from audio
    # is not then reported as missing.
    escalated = cfg.audio_escalation and audio is not None and result.is_ad != 1
    if escalated:
        n_calls += _escalate_to_audio(cfg, result, audio, meta, gen_ids, raws,
                                      trace=trace)

    missing = [f for f in ("is_ad", "has_food") if getattr(result, f) is None]
    if missing:
        errors.append(f"Model returned no usable value for: {', '.join(missing)}")
    if errors:
        result.error = "; ".join(errors)

    result.generation_id = json.dumps(gen_ids) if gen_ids else None
    result.raw_response = raws or None
    trace.error = result.error
    trace.labels = {f: getattr(result, f) for f in LABEL_FIELDS}
    logger.info(
        "bundle %s labelled in %.1fs: is_ad=%s has_food=%s is_upf=%s cost=$%.4f%s",
        bundle_id, time.monotonic() - started, result.is_ad, result.has_food,
        result.is_upf, result.cost_usd, " (with errors)" if result.error else "",
    )
    return result, n_calls, escalated


@dataclass
class RunSummary:
    run_id: str
    model: str
    mode: str
    bundle_size: int
    started_at: str
    finished_at: str
    n_images: int
    n_label_sets: int
    n_errors: int
    n_api_calls: int
    total_cost_usd: float
    mean_cost_per_image_usd: float
    mean_cost_per_call_usd: float
    total_prompt_tokens: int
    total_completion_tokens: int
    # How many units escalated to the audio channel, and what that cost.
    # n_escalations counts transcribe+judge attempts, so comparing it against
    # the number of units labelled is_ad != 1 is a direct check that the
    # trigger fired where it should have.
    #
    # Defaulted and placed last so that constructing a RunSummary without
    # them — every caller that predates audio escalation — still works.
    n_escalations: int = 0
    audio_cost_usd: float = 0.0


def run(cfg: Config,
        bundles: "list[list[Path]] | list[Bundle]") -> tuple[list[LabelResult], RunSummary]:
    """Label every bundle and return per-call results plus a run summary.

    `bundles` accepts a plain list[list[Path]] — what every existing caller
    passes — a list[Bundle] carrying per-video metadata, or a mix of both;
    see Bundle and _normalize_bundles.
    """
    bundles = _normalize_bundles(bundles)
    run_id = f"{datetime.now(timezone.utc):%Y%m%dT%H%M%SZ}-{uuid.uuid4().hex[:6]}"
    started_at = datetime.now(timezone.utc).isoformat()
    started_monotonic = time.monotonic()
    results: list[LabelResult] = []
    n_api_calls = 0
    n_escalations = 0
    logger.info(
        "run %s starting: %d bundle(s), model=%s, mode=%s",
        run_id, len(bundles), cfg.model, cfg.mode,
    )

    # One unit per bundle, always. A caller that wants a verdict per
    # image passes bundles of one image — which is exactly what the
    # removed agent_per_image mode produced, minus a second code path
    # that had to re-derive it here.
    units = [
        (f"{run_id}-b{position:04d}", bundle.images, bundle.meta, bundle.audio)
        for position, bundle in enumerate(bundles, start=1)
    ]

    # Two pools, not one. `agent_pool` is capped at cfg.max_workers and is
    # the *only* place a real HTTP call happens (inside _run_agent) — it
    # is the sole gate on concurrent API traffic. `unit_pool` exists only
    # to orchestrate units in parallel: each of its threads runs
    # _label_agent_unit, which submits 2-3 futures to agent_pool and
    # blocks on `.result()`. That block is pure I/O wait, not agent_pool
    # work, so unit_pool threads never occupy an agent_pool slot.
    #
    # This is deadlock-free by construction: a pool worker only ever
    # deadlocks by blocking on a future that needs a slot in its *own*
    # pool (all workers busy waiting on each other with no one left to
    # run the submitted task). Here unit_pool threads block on futures
    # submitted to agent_pool, never to unit_pool itself, and agent_pool
    # threads (_run_agent) never submit anything anywhere — they only
    # make an HTTP call and return. So there is no cycle in which a
    # worker waits on its own pool's capacity.
    #
    # unit_pool is sized generously (bounded only to avoid an absurd
    # thread count) because oversizing it just creates more threads that
    # sit blocked on I/O; it enforces no concurrency limit of its own.
    # The real ceiling — actual concurrent HTTP calls — comes entirely
    # from agent_pool's max_workers cap.
    unit_workers = max(1, min(len(units), max(cfg.max_workers * 4, 32)))
    with ThreadPoolExecutor(max_workers=cfg.max_workers) as agent_pool, \
            ThreadPoolExecutor(max_workers=unit_workers) as unit_pool:
        futures = [
            unit_pool.submit(_label_agent_unit, cfg, agent_pool, images,
                             bundle_id, meta, audio)
            for bundle_id, images, meta, audio in units
        ]
        for future in futures:
            result, n_calls, escalated = future.result()
            results.append(result)
            n_api_calls += n_calls
            n_escalations += int(escalated)
    total_cost = sum(r.cost_usd for r in results)
    n_images = sum(r.n_images for r in results)
    summary = RunSummary(
        run_id=run_id,
        model=cfg.model,
        mode=cfg.mode,
        bundle_size=max((len(b.images) for b in bundles), default=0),
        started_at=started_at,
        finished_at=datetime.now(timezone.utc).isoformat(),
        n_images=n_images,
        n_label_sets=len(results),
        n_errors=sum(1 for r in results if r.error),
        n_api_calls=n_api_calls,
        total_cost_usd=total_cost,
        n_escalations=n_escalations,
        audio_cost_usd=sum(r.audio_cost_usd for r in results),
        mean_cost_per_image_usd=total_cost / n_images if n_images else 0.0,
        mean_cost_per_call_usd=total_cost / n_api_calls if n_api_calls else 0.0,
        total_prompt_tokens=sum(r.prompt_tokens for r in results),
        total_completion_tokens=sum(r.completion_tokens for r in results),
    )
    logger.info(
        "run %s finished in %.1fs: %d label set(s), %d error(s), %d api call(s), "
        "cost=$%.4f",
        run_id, time.monotonic() - started_monotonic, len(results),
        summary.n_errors, n_api_calls, total_cost,
    )
    return results, summary
